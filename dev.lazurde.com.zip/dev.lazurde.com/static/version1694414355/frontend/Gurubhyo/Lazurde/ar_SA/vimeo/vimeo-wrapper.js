define(['vimeo'], function(Player) {
    'use strict';
    window.Vimeo = window.Vimeo || {
        'Player': Player
    };
});