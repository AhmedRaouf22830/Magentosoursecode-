define(['uiComponent', 'Mageplaza_QuickCart/js/model/config', 'Magento_Customer/js/customer-data', 'mage/translate', 'jquery', 'jquery/jquery.cookie'], function(Component, config, customerData, $t, $) {
    'use strict';
    var guestUrl = 'guest-carts/:cartId/coupons/:couponCode',
        customerUrl = 'carts/mine/coupons/:couponCode';
    return Component.extend({
        getTotals: function() {
            var cartData = customerData.get('cart')();
            var cartCusData = [];
            if (cartData.mpquickcart != undefined) {
                cartData.mpquickcart.totals.forEach(val => {
                    if (val.code != 'amasty_checkout' && val.code != 'tax') {
                        cartCusData.push({
                            "code": val.code,
                            "title": val.title,
                            "value": val.value,
                            "area": val.area
                        })
                    }
                    if (val.code == 'discountFirst') {
                        var check_cookie = $.cookie('discountFirst');
                        if (check_cookie != "discountapply") {}
                    }
                });
            }
            if (cartData.hasOwnProperty('mpquickcart') && config.getMpConfig('showFull')) {
                return cartCusData;
            }
            return [{
                'title': $t('Subtotal'),
                'value': cartData.subtotal,
                'code': 'subtotal'
            }];
        },
        getValue: function(value) {
            return value;
        },
        buildUrl: function(cartId, couponCode) {
            var url = guestUrl;
            var cartData = customerData.get('cart')();
            if (cartData.mpquickcart.isLoggedIn) {
                url = customerUrl;
            }
            return cartData.mpquickcart.apiUrl + url.replace(':cartId', cartId).replace(':couponCode', couponCode);
        }
    });
});