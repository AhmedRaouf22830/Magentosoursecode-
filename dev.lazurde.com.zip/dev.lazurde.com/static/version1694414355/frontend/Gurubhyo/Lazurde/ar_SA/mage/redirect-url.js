define(['jquery', 'jquery-ui-modules/widget'], function($) {
    'use strict';
    $.widget('mage.redirectUrl', {
        options: {
            event: 'click',
            url: undefined
        },
        _bind: function() {
            var handlers = {};
            handlers[this.options.event] = '_onEvent';
            this._on(handlers);
        },
        _create: function() {
            this._bind();
        },
        _onEvent: function() {
            if (this.options.url) {
                location.href = this.options.url;
            } else {
                location.href = this.element.val();
            }
        }
    });
    return $.mage.redirectUrl;
});