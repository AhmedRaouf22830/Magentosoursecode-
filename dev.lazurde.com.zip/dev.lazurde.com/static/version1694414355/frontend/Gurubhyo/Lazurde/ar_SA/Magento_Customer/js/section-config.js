define(['underscore'], function(_) {
    'use strict';
    var baseUrls = [],
        sections = [],
        clientSideSections = [],
        sectionNames = [],
        canonize;
    canonize = function(url) {
        var route = url;
        _.some(baseUrls, function(baseUrl) {
            route = url.replace(baseUrl, '');
            return route !== url;
        });
        return route.replace(/^\/?index.php\/?/, '').toLowerCase();
    };
    return {
        getAffectedSections: function(url) {
            var route = canonize(url),
                actions = _.find(sections, function(val, section) {
                    var matched;
                    if (section.indexOf('*') >= 0) {
                        section = section.replace(/\*/g, '[^/]+') + '$';
                        matched = route.match(section);
                        return matched && matched[0] === route;
                    }
                    return route.indexOf(section) === 0;
                });
            return _.union(_.toArray(actions), sections['*']);
        },
        filterClientSideSections: function(allSections) {
            return _.difference(allSections, clientSideSections);
        },
        isClientSideSection: function(sectionName) {
            return _.contains(clientSideSections, sectionName);
        },
        getSectionNames: function() {
            return sectionNames;
        },
        'Magento_Customer/js/section-config': function(options) {
            baseUrls = options.baseUrls;
            sections = options.sections;
            clientSideSections = options.clientSideSections;
            sectionNames = options.sectionNames;
        }
    };
});