define(['./messages'], function(Messages) {
    'use strict';
    return new Messages();
});