define(['uiComponent', 'Magento_Customer/js/customer-data', 'jquery', 'ko', 'underscore', 'jquery/jquery.cookie', 'sidebar', 'mage/translate', 'mage/dropdown'], function(Component, customerData, $, ko, _, cookie) {
    'use strict';
    var sidebarInitialized = false,
        addToCartCalls = 0,
        miniCart;
    miniCart = $('[data-block=\'minicart\']');

    function initSidebar() {
        if (miniCart.data('mageSidebar')) {
            miniCart.sidebar('update');
        }
        if (!$('[data-role=product-item]').length) {
            return false;
        }
        miniCart.trigger('contentUpdated');
        if (sidebarInitialized) {
            return false;
        }
        sidebarInitialized = true;
        miniCart.sidebar({
            'targetElement': 'div.block.block-minicart',
            'url': {
                'checkout': window.checkout.checkoutUrl,
                'update': window.checkout.updateItemQtyUrl,
                'remove': window.checkout.removeItemUrl,
                'loginUrl': window.checkout.customerLoginUrl,
                'isRedirectRequired': window.checkout.isRedirectRequired
            },
            'button': {
                'checkout': '#top-cart-btn-checkout',
                'remove': '#mini-cart a.action.delete',
                'close': '#btn-minicart-close'
            },
            'showcart': {
                'parent': 'span.counter',
                'qty': 'span.counter-number',
                'label': 'span.counter-label'
            },
            'minicart': {
                'list': '#mini-cart',
                'content': '#minicart-content-wrapper',
                'qty': 'div.items-total',
                'subtotal': 'div.subtotal span.price',
                'maxItemsVisible': window.checkout.minicartMaxItemsVisible
            },
            'item': {
                'qty': ':input.cart-item-qty',
                'button': ':button.update-cart-item'
            },
            'confirmMessage': $.mage.__('Are you sure you would like to remove this item from the shopping cart?')
        });
    }
    miniCart.on('dropdowndialogopen', function() {
        initSidebar();
    });
    return Component.extend({
        shoppingCartUrl: window.checkout.shoppingCartUrl,
        maxItemsToDisplay: window.checkout.maxItemsToDisplay,
        cart: {},
        initialize: function() {
            var self = this,
                cartData = customerData.get('cart');
            this.update(cartData());
            cartData.subscribe(function(updatedCart) {
                addToCartCalls--;
                this.isLoading(addToCartCalls > 0);
                sidebarInitialized = false;
                this.update(updatedCart);
                initSidebar();
            }, this);
            $('[data-block="minicart"]').on('contentLoading', function() {
                addToCartCalls++;
                self.isLoading(true);
            });
            if (cartData().website_id !== window.checkout.websiteId && cartData().website_id !== undefined || cartData().storeId !== window.checkout.storeId && cartData().storeId !== undefined) {
                customerData.reload(['cart'], false);
            }
            return this._super();
        },
        isLoading: ko.observable(false),
        initSidebar: initSidebar,
        closeMinicart: function(event) {
            var url = window.location.href;
            var customer = customerData.get('customer');
            var user_type = customer().firstname ? "Registered" : "Guest";
            var cart = this.getCartParam('items');
            var carArr = cart;
            var jsonObj = [];
            const checkoutstep1 = localStorage.getItem('checkoutstep1') == null ? false : localStorage.getItem('checkoutstep1');
            if (carArr != undefined && carArr.length > 0) {
                carArr.forEach(function(item, index) {
                    jsonObj.push({
                        'name': item.product_name,
                        'id': item.product_id,
                        'price': item.product_price_value,
                        'category': item.category,
                        'quantity': item.qty,
                        'sku': item.product_sku
                    });
                });
                if (event != undefined && event.type == "click") {
                    $.cookie('step2', null, {
                        path: '/',
                        expires: -1
                    });
                    dataLayer.push({
                        'event': 'checkout',
                        'eventCategory': 'Checkout',
                        'eventAction': 'Checkoutclick',
                        'eventLabel': '1',
                        'ecommerce': {
                            'checkout': {
                                'actionField': {
                                    'step': 1,
                                    'option': user_type
                                },
                                'products': jsonObj
                            }
                        }
                    });
                    localStorage.removeItem('checkoutstep1');
                }
                if (url.includes('checkout') && url.includes('cart') == false && checkoutstep1 == false) {
                    localStorage.setItem('checkoutstep1', 'true');
                }
            }
            $('[data-block="minicart"]').find('[data-role="dropdownDialog"]').dropdownDialog('close');
        },
        closeSidebar: function() {
            var minicart = $('[data-block="minicart"]');
            minicart.on('click', '[data-action="close"]', function(event) {
                event.stopPropagation();
                minicart.find('[data-role="dropdownDialog"]').dropdownDialog('close');
            });
            return true;
        },
        getItemRenderer: function(productType) {
            return this.itemRenderer[productType] || 'defaultRenderer';
        },
        update: function(updatedCart) {
            _.each(updatedCart, function(value, key) {
                if (!this.cart.hasOwnProperty(key)) {
                    this.cart[key] = ko.observable();
                }
                this.cart[key](value);
            }, this);
        },
        getCartParam: function(name) {
            if (!_.isUndefined(name)) {
                if (!this.cart.hasOwnProperty(name)) {
                    this.cart[name] = ko.observable();
                }
            }
            return this.cart[name]();
        },
        getCartItems: function() {
            var items = this.getCartParam('items') || [];
            items = items.slice(parseInt(-this.maxItemsToDisplay, 10));
            return items;
        },
        getCartLineItemsCount: function() {
            var items = this.getCartParam('items') || [];
            return parseInt(items.length, 10);
        }
    });
});