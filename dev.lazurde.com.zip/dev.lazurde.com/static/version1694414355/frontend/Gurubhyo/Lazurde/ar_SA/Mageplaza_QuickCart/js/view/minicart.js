define(['jquery', 'Magento_Checkout/js/view/minicart', 'Mageplaza_QuickCart/js/model/config', 'Magento_Ui/js/modal/modal', 'mage/translate', 'Magento_Customer/js/customer-data'], function($, Component, config, modal, $t, customerData) {
    'use strict';
    return Component.extend({
        closeModalTimeout: null,
        setModalElement: function(element) {
            var self = this,
                options;
            options = {
                'id': 'mpquickcart',
                'type': 'slide',
                'title': $t('Shopping Cart'),
                'modalClass': 'mpquickcart',
                'responsive': true,
                'innerScroll': true,
                'trigger': '.showcart',
                'buttons': [],
                'parentModalClass': '_has-modal mpquickcart-has-modal',
                'opened': function(e) {
                    $('div.block.block-minicart').trigger('dropdowndialogopen');
                    $('._hj_feedback_container').hide();
                },
                'closed': function() {
                    $('div.block.block-minicart').trigger('dropdowndialogclose');
                    $('._hj_feedback_container').show();
                }
            };
            this.modalWindow = element;
            modal(options, $(this.modalWindow));
            if (config.getMpConfig('isHover')) {
                $('.showcart').on('mouseover', function() {
                    self.showModal();
                });
                $('.mpquickcart').on('mouseover', function() {
                    clearTimeout(self.closeModalTimeout);
                }).on('mouseleave', function() {
                    self.closeModalTimeout = setTimeout(function() {
                        self.closeModal();
                    }, 500);
                });
            }
        },
        showModal: function() {
            $(this.modalWindow).modal('openModal');
            $('._hj_feedback_container').hide();
        },
        closeModal: function() {
            $(this.modalWindow).modal('closeModal');
            $('._hj_feedback_container').show();
        },
        minusQty: function(item, event) {
            $('body').trigger('processStart');
            var target = $(event.target).prev();
            if (target.val() <= 1) {
                $('body').trigger('processStop');
                return;
            }
            target.val(Number(target.val()) - 1);
            $(event.target).next().trigger('click');
            target.trigger('change');
            setTimeout(function() {
                $('body').trigger('processStop');
            }, 3000);
        },
        getStoreCode: function() {
            var cartData = customerData.get('cart')();
            return cartData.mpquickcart.storeCode;
        },
        plusQty: function(item, event) {
            $('body').trigger('processStart');
            var target = $(event.target).next();
            target.val(Number(target.val()) + 1);
            $(event.target).next().next().next().trigger('click');
            target.trigger('change');
            setTimeout(function() {
                $('body').trigger('processStop');
            }, 3000);
        }
    });
});