define(function() {
    'use strict';
    return {
        'reset': '#reset',
        'save': '#save',
        'saveAndContinue': '#save_and_continue'
    };
});