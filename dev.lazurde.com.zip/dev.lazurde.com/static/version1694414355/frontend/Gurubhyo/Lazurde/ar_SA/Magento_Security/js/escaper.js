define([], function() {
    'use strict';
    return {
        neverAllowedElements: ['script', 'img', 'embed', 'iframe', 'video', 'source', 'object', 'audio'],
        generallyAllowedAttributes: ['id', 'class', 'href', 'title', 'style'],
        forbiddenAttributesByElement: {
            a: ['style']
        },
        escapeHtml: function(data, allowedTags) {
            var domParser = new DOMParser(),
                fragment = domParser.parseFromString('<div></div>', 'text/html');
            fragment = fragment.body.childNodes[0];
            allowedTags = typeof allowedTags === 'object' && allowedTags.length ? allowedTags : null;
            if (allowedTags) {
                fragment.innerHTML = data || '';
                allowedTags = this._filterProhibitedTags(allowedTags);
                this._removeComments(fragment);
                this._removeNotAllowedElements(fragment, allowedTags);
                this._removeNotAllowedAttributes(fragment);
                return fragment.innerHTML;
            }
            fragment.textContent = data || '';
            return fragment.innerHTML;
        },
        _filterProhibitedTags: function(tags) {
            return tags.filter(function(n) {
                return this.neverAllowedElements.indexOf(n) === -1;
            }.bind(this));
        },
        _removeComments: function(node) {
            var treeWalker = node.ownerDocument.createTreeWalker(node, NodeFilter.SHOW_COMMENT, function() {
                    return NodeFilter.FILTER_ACCEPT;
                }, false),
                nodesToRemove = [];
            while (treeWalker.nextNode()) {
                nodesToRemove.push(treeWalker.currentNode);
            }
            nodesToRemove.forEach(function(nodeToRemove) {
                nodeToRemove.parentNode.removeChild(nodeToRemove);
            });
        },
        _removeNotAllowedElements: function(node, allowedTags) {
            var treeWalker = node.ownerDocument.createTreeWalker(node, NodeFilter.SHOW_ELEMENT, function(currentNode) {
                    return allowedTags.indexOf(currentNode.nodeName.toLowerCase()) === -1 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
                }, false),
                nodesToRemove = [];
            while (treeWalker.nextNode()) {
                if (allowedTags.indexOf(treeWalker.currentNode.nodeName.toLowerCase()) === -1) {
                    nodesToRemove.push(treeWalker.currentNode);
                }
            }
            nodesToRemove.forEach(function(nodeToRemove) {
                nodeToRemove.parentNode.replaceChild(node.ownerDocument.createTextNode(nodeToRemove.textContent), nodeToRemove);
            });
        },
        _removeNotAllowedAttributes: function(node) {
            var treeWalker = node.ownerDocument.createTreeWalker(node, NodeFilter.SHOW_ELEMENT, function() {
                    return NodeFilter.FILTER_ACCEPT;
                }, false),
                i, attribute, nodeName, attributesToRemove = [];
            while (treeWalker.nextNode()) {
                for (i = 0; i < treeWalker.currentNode.attributes.length; i++) {
                    attribute = treeWalker.currentNode.attributes[i];
                    nodeName = treeWalker.currentNode.nodeName.toLowerCase();
                    if (this.generallyAllowedAttributes.indexOf(attribute.name) === -1 || this._checkHrefValue(attribute) || this.forbiddenAttributesByElement[nodeName] && this.forbiddenAttributesByElement[nodeName].indexOf(attribute.name) !== -1) {
                        attributesToRemove.push(attribute);
                    }
                }
            }
            attributesToRemove.forEach(function(attributeToRemove) {
                attributeToRemove.ownerElement.removeAttribute(attributeToRemove.name);
            });
        },
        _checkHrefValue: function(attribute) {
            return attribute.nodeName === 'href' && attribute.nodeValue.startsWith('javascript');
        }
    };
});