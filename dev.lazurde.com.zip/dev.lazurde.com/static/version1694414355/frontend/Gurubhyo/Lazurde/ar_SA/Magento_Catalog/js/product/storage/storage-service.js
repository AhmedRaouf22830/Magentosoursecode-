define(['jquery', 'underscore', 'mageUtils', 'mage/translate', 'Magento_Catalog/js/product/storage/ids-storage', 'Magento_Catalog/js/product/storage/data-storage', 'Magento_Catalog/js/product/storage/ids-storage-compare'], function($, _, utils, $t, IdsStorage, DataStore, IdsStorageCompare) {
    'use strict';
    return (function() {
        var
            storages = {},
            classes = {},
            prototype = {
                set: function(data) {
                    if (!utils.compare(data, this.data()).equal) {
                        this.data(data);
                    }
                },
                add: function(data) {
                    if (!_.isEmpty(data)) {
                        this.data(_.extend(utils.copy(this.data()), data));
                    }
                },
                get: function() {
                    return this.data();
                }
            },
            storagesInterface = {
                data: 'function',
                initialize: 'function',
                namespace: 'string'
            },
            _private = {
                overrideClassMethods: function(extensionMethods, originInstance) {
                    var methodsName = _.keys(extensionMethods),
                        i = 0,
                        length = methodsName.length;
                    for (i; i < length; i++) {
                        if (_.isFunction(originInstance[methodsName[i]])) {
                            originInstance[methodsName[i]] = extensionMethods[methodsName[i]];
                        }
                    }
                    return originInstance;
                },
                isImplementInterface: function(classInstance) {
                    _.each(storagesInterface, function(key, value) {
                        if (typeof classInstance[key] !== value) {
                            return false;
                        }
                    });
                    return true;
                }
            },
            subsctibers = {};
        (function() {
            classes[IdsStorage.name] = function(config) {
                _.extend(this, IdsStorage, config);
            };
            classes[IdsStorageCompare.name] = function(config) {
                _.extend(this, IdsStorageCompare, config);
            };
            classes[DataStore.name] = function(config) {
                _.extend(this, DataStore, config);
            };
            _.each(classes, function(classItem) {
                classItem.prototype = prototype;
            });
        })();
        return {
            createStorage: function(config) {
                var instance, initialized;
                if (storages[config.namespace]) {
                    return storages[config.namespace];
                }
                instance = new classes[config.className](config);
                if (_private.isImplementInterface(instance)) {
                    initialized = storages[config.namespace] = instance.initialize();
                    this.processSubscribers(initialized, config);
                    return initialized;
                }
                throw new Error('Class ' + config.className + $t('does not implement Storage Interface'));
            },
            processSubscribers: function(initialized, config) {
                if (subsctibers[config.namespace]) {
                    _.each(subsctibers[config.namespace], function(callback) {
                        callback(initialized);
                    });
                    delete subsctibers[config.namespace];
                }
            },
            onStorageInit: function(namespace, callback) {
                if (storages[namespace]) {
                    callback(storages[namespace]);
                } else {
                    subsctibers[namespace] ? subsctibers[namespace].push(callback) : subsctibers[namespace] = [callback];
                }
            },
            getStorage: function(namespace) {
                return storages[namespace];
            }
        };
    })();
});