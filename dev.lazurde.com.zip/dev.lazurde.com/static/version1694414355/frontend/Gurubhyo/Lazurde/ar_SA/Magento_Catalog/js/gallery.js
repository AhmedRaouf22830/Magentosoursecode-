define(['jquery', 'jquery-ui-modules/widget'], function($) {
    'use strict';
    $.widget('mage.gallery', {
        options: {
            minWidth: 300,
            widthOffset: 90,
            heightOffset: 210,
            closeWindow: 'div.buttons-set a[role="close-window"]'
        },
        _create: function() {
            $(this.options.closeWindow).on('click', function() {
                window.close();
            });
            this._resizeWindow();
        },
        _resizeWindow: function() {
            var img = this.element,
                width = img.width() < this.options.minWidth ? this.options.minWidth : img.width();
            window.resizeTo(width + this.options.widthOffset, img.height() + this.options.heightOffset);
        }
    });
    return $.mage.gallery;
});