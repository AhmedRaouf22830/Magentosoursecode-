define(["jquery.bootstrap", "jquery.boxslider", "owlcarousel", "flexslider", "fancybox", "select2", "slick", 'jquery', 'Magento_Ui/js/modal/modal'], function($, jQueryBootstrap, jqueryBoxslider, select2, owlcarousel, flexslider, fancybox, slick, modal) {
    "use strict";
    jQuery(".cta-content.account").hover(function() {
        jQuery('.flyout-container-myaccount').addClass('open');
        jQuery('.right-container').addClass('active');
    }, function() {
        jQuery('.flyout-container-myaccount').removeClass('open');
        jQuery('.right-container').removeClass('active');
    });
    jQuery(".cta-content.wishlist").hover(function() {
        jQuery('.flyout-mywishlist-content').addClass('open');
        jQuery('.right-container').addClass('active');
    }, function() {
        jQuery('.flyout-mywishlist-content').removeClass('open');
        jQuery('.right-container').removeClass('active');
    });
    jQuery(".cta-content.minicart").hover(function() {
        jQuery('.flyout-container-minicart').addClass('open');
        jQuery('.right-container').addClass('active');
    }, function() {
        jQuery('.flyout-container-minicart').removeClass('open');
        jQuery('.right-container').removeClass('active');
    });
    var scroolBtn = jQuery('#scroll_to_top_button');
    jQuery(window).scroll(function() {
        if (jQuery(window).scrollTop() > 300) {
            scroolBtn.addClass('show');
        } else {
            scroolBtn.removeClass('show');
        }
    });
    scroolBtn.on('click', function(e) {
        e.preventDefault();
        jQuery('html, body').animate({
            scrollTop: 0
        }, '300');
    });
    jQuery(window).scroll(function() {
        if (jQuery(window).scrollTop() >= 300) {
            jQuery('.header-active').addClass('fixed-header');
        } else {
            jQuery('.header-active').removeClass('fixed-header');
        }
    });
    jQuery(".collapse.show").each(function() {
        jQuery(this).prev(".prodect-detailed-title").find(".fa").addClass("fa-minus").removeClass("fa-plus");
    });
    jQuery(".collapse").on('show.bs.collapse', function() {
        jQuery(this).prev(".prodect-detailed-title").find(".fa").removeClass("fa-plus").addClass("fa-minus");
    }).on('hide.bs.collapse', function() {
        jQuery(this).prev(".prodect-detailed-title").find(".fa").removeClass("fa-minus").addClass("fa-plus");
    });
    jQuery(".collapse.show").each(function() {
        jQuery(this).prev(".concierge-flyout-drawer-wrapper").find(".fa").addClass("fa-caret-down").removeClass("fa-caret-right");
    });
    jQuery(".collapse").on('show.bs.collapse', function() {
        jQuery(this).prev(".concierge-flyout-drawer-wrapper").find(".fa").removeClass("fa-caret-right").addClass("fa-caret-down");
    }).on('hide.bs.collapse', function() {
        jQuery(this).prev(".concierge-flyout-drawer-wrapper").find(".fa").removeClass("fa-caret-down").addClass("fa-caret-right");
    });
    jQuery('.main').on("click", '.cart_qty_dec', function() {
        var input = jQuery(this).closest('.qty').find('input');
        var value = parseInt(input.val());
        if (value) input.val(value - 1);
    });
    jQuery('.main').on("click", '.cart_qty_inc', function() {
        var input = jQuery(this).closest('.qty').find('input');
        var value = parseInt(input.val());
        input.val(value + 1);
    });
    jQuery('input[name="dob"]').attr('placeholder', 'Date of Birth');
    jQuery(".regulars").slick({
        dots: false,
        infinite: true,
        slidesToShow: 5,
        slidesToScroll: 5
    });
    jQuery(".tous-modal-list .show-popup").click(function() {
        if (jQuery(this).hasClass("active")) {
            jQuery(this).removeClass("active");
            jQuery(this).next().slideUp();
        } else {
            jQuery(".tous-modal-list .show-popup").removeClass("active");
            jQuery(this).addClass("active");
            jQuery(".tous-modal-list .show-popup").next().slideUp();
            jQuery(this).next().slideDown();
        };
    });
    jQuery('.new-category-carousel').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        dots: false,
        navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 3
            },
            1000: {
                items: 4
            }
        }
    })
    jQuery(".account-icon").click(function() {
        jQuery('.mobilesignin-drop').slideToggle();
        jQuery('.switcher-trigger').removeClass('active');
        jQuery('.switcher-options').removeClass('active');
        return false
    });
    jQuery("body").click(function() {
        jQuery('.mobilesignin-drop').slideUp();
    });
    jQuery(".switcher-options").click(function() {
        jQuery('.mobilesignin-drop').slideUp();
    });
    jQuery(".switcher-trigger").click(function() {
        jQuery('.mobilesignin-drop').slideUp();
    });
    jQuery(".filter-by").click(function() {
        jQuery(".sidebar.sidebar-main").addClass('opened-sidebar')
    });
    jQuery(".close-filter-by, .apply-filt, .mobi-appi-layer").click(function() {
        jQuery(".sidebar.sidebar-main").removeClass('opened-sidebar')
    });
    jQuery(".sort-by").click(function() {
        jQuery(".sorts-value").addClass('opened-sort')
    });
    jQuery(".close-sort-by").click(function() {
        jQuery(".sorts-value").removeClass('opened-sort')
    });
    jQuery('body').on('click', '.close-filter-by, .apply-filt, .mobi-appi-layer', function() {
        jQuery(this).closest('.sidebar-main').removeClass('opened-sidebar')
    });
    jQuery('.ecom-service-carousel').owlCarousel({
        margin: 0,
        nav: false,
        dots: true,
        mouseDrag: true,
        responsiveClass: true,
        autoplay: false,
        responsive: {
            0: {
                items: 1,
                loop: true,
                mouseDrag: true,
                autoplay: true
            },
            575: {
                items: 2,
                loop: true,
                mouseDrag: true,
                autoplay: true
            },
            768: {
                items: 3,
                loop: true,
                mouseDrag: true,
                autoplay: true
            },
            992: {
                items: 4,
                loop: false
            }
        }
    })
});