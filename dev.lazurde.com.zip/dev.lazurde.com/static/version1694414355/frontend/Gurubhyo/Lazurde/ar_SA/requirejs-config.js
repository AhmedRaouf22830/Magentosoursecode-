(function(require) {
    (function() {
        var config = {
            map: {
                '*': {
                    directoryRegionUpdater: 'Magento_Directory/js/region-updater'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            waitSeconds: 0,
            map: {
                '*': {
                    'ko': 'knockoutjs/knockout',
                    'knockout': 'knockoutjs/knockout',
                    'mageUtils': 'mage/utils/main',
                    'rjsResolver': 'mage/requirejs/resolver',
                    'jquery-ui-modules/core': 'jquery/ui-modules/core',
                    'jquery-ui-modules/accordion': 'jquery/ui-modules/widgets/accordion',
                    'jquery-ui-modules/autocomplete': 'jquery/ui-modules/widgets/autocomplete',
                    'jquery-ui-modules/button': 'jquery/ui-modules/widgets/button',
                    'jquery-ui-modules/datepicker': 'jquery/ui-modules/widgets/datepicker',
                    'jquery-ui-modules/dialog': 'jquery/ui-modules/widgets/dialog',
                    'jquery-ui-modules/draggable': 'jquery/ui-modules/widgets/draggable',
                    'jquery-ui-modules/droppable': 'jquery/ui-modules/widgets/droppable',
                    'jquery-ui-modules/effect-blind': 'jquery/ui-modules/effects/effect-blind',
                    'jquery-ui-modules/effect-bounce': 'jquery/ui-modules/effects/effect-bounce',
                    'jquery-ui-modules/effect-clip': 'jquery/ui-modules/effects/effect-clip',
                    'jquery-ui-modules/effect-drop': 'jquery/ui-modules/effects/effect-drop',
                    'jquery-ui-modules/effect-explode': 'jquery/ui-modules/effects/effect-explode',
                    'jquery-ui-modules/effect-fade': 'jquery/ui-modules/effects/effect-fade',
                    'jquery-ui-modules/effect-fold': 'jquery/ui-modules/effects/effect-fold',
                    'jquery-ui-modules/effect-highlight': 'jquery/ui-modules/effects/effect-highlight',
                    'jquery-ui-modules/effect-scale': 'jquery/ui-modules/effects/effect-scale',
                    'jquery-ui-modules/effect-pulsate': 'jquery/ui-modules/effects/effect-pulsate',
                    'jquery-ui-modules/effect-shake': 'jquery/ui-modules/effects/effect-shake',
                    'jquery-ui-modules/effect-slide': 'jquery/ui-modules/effects/effect-slide',
                    'jquery-ui-modules/effect-transfer': 'jquery/ui-modules/effects/effect-transfer',
                    'jquery-ui-modules/effect': 'jquery/ui-modules/effect',
                    'jquery-ui-modules/menu': 'jquery/ui-modules/widgets/menu',
                    'jquery-ui-modules/mouse': 'jquery/ui-modules/widgets/mouse',
                    'jquery-ui-modules/position': 'jquery/ui-modules/position',
                    'jquery-ui-modules/progressbar': 'jquery/ui-modules/widgets/progressbar',
                    'jquery-ui-modules/resizable': 'jquery/ui-modules/widgets/resizable',
                    'jquery-ui-modules/selectable': 'jquery/ui-modules/widgets/selectable',
                    'jquery-ui-modules/selectmenu': 'jquery/ui-modules/widgets/selectmenu',
                    'jquery-ui-modules/slider': 'jquery/ui-modules/widgets/slider',
                    'jquery-ui-modules/sortable': 'jquery/ui-modules/widgets/sortable',
                    'jquery-ui-modules/spinner': 'jquery/ui-modules/widgets/spinner',
                    'jquery-ui-modules/tabs': 'jquery/ui-modules/widgets/tabs',
                    'jquery-ui-modules/tooltip': 'jquery/ui-modules/widgets/tooltip',
                    'jquery-ui-modules/widget': 'jquery/ui-modules/widget',
                    'jquery-ui-modules/timepicker': 'jquery/timepicker',
                    'vimeo': 'vimeo/player',
                    'vimeoWrapper': 'vimeo/vimeo-wrapper'
                }
            },
            shim: {
                'mage/adminhtml/backup': ['prototype'],
                'mage/captcha': ['prototype'],
                'mage/new-gallery': ['jquery'],
                'jquery/ui': ['jquery'],
                'matchMedia': {
                    'exports': 'mediaCheck'
                },
                'magnifier/magnifier': ['jquery'],
                'vimeo/player': {
                    'exports': 'Player'
                }
            },
            paths: {
                'jquery/validate': 'jquery/jquery.validate',
                'jquery/file-uploader': 'jquery/fileUploader/jquery.fileuploader',
                'prototype': 'legacy-build.min',
                'jquery/jquery-storageapi': 'js-storage/storage-wrapper',
                'text': 'mage/requirejs/text',
                'domReady': 'requirejs/domReady',
                'spectrum': 'jquery/spectrum/spectrum',
                'tinycolor': 'jquery/spectrum/tinycolor',
                'jquery-ui-modules': 'jquery/ui-modules'
            },
            config: {
                text: {
                    'headers': {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                }
            }
        };
        require(['jquery'], function($) {
            'use strict';
            $.noConflict();
        });
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    'rowBuilder': 'Magento_Theme/js/row-builder',
                    'toggleAdvanced': 'mage/toggle',
                    'translateInline': 'mage/translate-inline',
                    'sticky': 'mage/sticky',
                    'tabs': 'mage/tabs',
                    'collapsible': 'mage/collapsible',
                    'dropdownDialog': 'mage/dropdown',
                    'dropdown': 'mage/dropdowns',
                    'accordion': 'mage/accordion',
                    'loader': 'mage/loader',
                    'tooltip': 'mage/tooltip',
                    'deletableItem': 'mage/deletable-item',
                    'itemTable': 'mage/item-table',
                    'fieldsetControls': 'mage/fieldset-controls',
                    'fieldsetResetControl': 'mage/fieldset-controls',
                    'redirectUrl': 'mage/redirect-url',
                    'loaderAjax': 'mage/loader',
                    'menu': 'mage/menu',
                    'popupWindow': 'mage/popup-window',
                    'validation': 'mage/validation/validation',
                    'breadcrumbs': 'Magento_Theme/js/view/breadcrumbs',
                    'jquery/ui': 'jquery/compat',
                    'cookieStatus': 'Magento_Theme/js/cookie-status'
                }
            },
            deps: ['mage/common', 'mage/dataPost', 'mage/bootstrap'],
            config: {
                mixins: {
                    'Magento_Theme/js/view/breadcrumbs': {
                        'Magento_Theme/js/view/add-home-breadcrumb': true
                    }
                }
            }
        };
        if (typeof window !== 'undefined' && window.document) {
            try {
                if (!window.localStorage || !window.sessionStorage) {
                    throw new Error();
                }
                localStorage.setItem('storage_test', 1);
                localStorage.removeItem('storage_test');
            } catch (e) {
                config.deps.push('mage/polyfill');
            }
        }
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    checkoutBalance: 'Magento_Customer/js/checkout-balance',
                    address: 'Magento_Customer/js/address',
                    changeEmailPassword: 'Magento_Customer/js/change-email-password',
                    passwordStrengthIndicator: 'Magento_Customer/js/password-strength-indicator',
                    zxcvbn: 'Magento_Customer/js/zxcvbn',
                    addressValidation: 'Magento_Customer/js/addressValidation',
                    showPassword: 'Magento_Customer/js/show-password',
                    'Magento_Customer/address': 'Magento_Customer/js/address',
                    'Magento_Customer/change-email-password': 'Magento_Customer/js/change-email-password',
                    globalSessionLoader: 'Magento_Customer/js/customer-global-session-loader.js'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    escaper: 'Magento_Security/js/escaper'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    quickSearch: 'Magento_Search/js/form-mini',
                    'Magento_Search/form-mini': 'Magento_Search/js/form-mini'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    priceBox: 'Magento_Catalog/js/price-box',
                    priceOptionDate: 'Magento_Catalog/js/price-option-date',
                    priceOptionFile: 'Magento_Catalog/js/price-option-file',
                    priceOptions: 'Magento_Catalog/js/price-options',
                    priceUtils: 'Magento_Catalog/js/price-utils'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    compareList: 'Magento_Catalog/js/list',
                    relatedProducts: 'Magento_Catalog/js/related-products',
                    upsellProducts: 'Magento_Catalog/js/upsell-products',
                    productListToolbarForm: 'Magento_Catalog/js/product/list/toolbar',
                    catalogGallery: 'Magento_Catalog/js/gallery',
                    catalogAddToCart: 'Magento_Catalog/js/catalog-add-to-cart'
                }
            },
            config: {
                mixins: {
                    'Magento_Theme/js/view/breadcrumbs': {
                        'Magento_Catalog/js/product/breadcrumbs': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    addToCart: 'Magento_Msrp/js/msrp'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    catalogSearch: 'Magento_CatalogSearch/form-mini'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    creditCardType: 'Magento_Payment/js/cc-type',
                    'Magento_Payment/cc-type': 'Magento_Payment/js/cc-type'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    giftMessage: 'Magento_Sales/js/gift-message',
                    ordersReturns: 'Magento_Sales/js/orders-returns',
                    'Magento_Sales/gift-message': 'Magento_Sales/js/gift-message',
                    'Magento_Sales/orders-returns': 'Magento_Sales/js/orders-returns'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    discountCode: 'Magento_Checkout/js/discount-codes',
                    shoppingCart: 'Magento_Checkout/js/shopping-cart',
                    regionUpdater: 'Magento_Checkout/js/region-updater',
                    sidebar: 'Magento_Checkout/js/sidebar',
                    checkoutLoader: 'Magento_Checkout/js/checkout-loader',
                    checkoutData: 'Magento_Checkout/js/checkout-data',
                    proceedToCheckout: 'Magento_Checkout/js/proceed-to-checkout',
                    catalogAddToCart: 'Magento_Catalog/js/catalog-add-to-cart'
                }
            },
            shim: {
                'Magento_Checkout/js/model/totals': {
                    deps: ['Magento_Customer/js/customer-data']
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    requireCookie: 'Magento_Cookie/js/require-cookie',
                    cookieNotices: 'Magento_Cookie/js/notices'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    downloadable: 'Magento_Downloadable/js/downloadable',
                    'Magento_Downloadable/downloadable': 'Magento_Downloadable/js/downloadable'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    bundleOption: 'Magento_Bundle/bundle',
                    priceBundle: 'Magento_Bundle/js/price-bundle',
                    slide: 'Magento_Bundle/js/slide',
                    productSummary: 'Magento_Bundle/js/product-summary'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    giftOptions: 'Magento_GiftMessage/js/gift-options',
                    'Magento_GiftMessage/gift-options': 'Magento_GiftMessage/js/gift-options'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            deps: [],
            shim: {
                'chartjs/chartjs-adapter-moment': ['moment'],
                'chartjs/es6-shim.min': {},
                'tiny_mce_5/tinymce.min': {
                    exports: 'tinyMCE'
                }
            },
            paths: {
                'ui/template': 'Magento_Ui/templates'
            },
            map: {
                '*': {
                    uiElement: 'Magento_Ui/js/lib/core/element/element',
                    uiCollection: 'Magento_Ui/js/lib/core/collection',
                    uiComponent: 'Magento_Ui/js/lib/core/collection',
                    uiClass: 'Magento_Ui/js/lib/core/class',
                    uiEvents: 'Magento_Ui/js/lib/core/events',
                    uiRegistry: 'Magento_Ui/js/lib/registry/registry',
                    consoleLogger: 'Magento_Ui/js/lib/logger/console-logger',
                    uiLayout: 'Magento_Ui/js/core/renderer/layout',
                    buttonAdapter: 'Magento_Ui/js/form/button-adapter',
                    chartJs: 'chartjs/Chart.min',
                    'chart.js': 'chartjs/Chart.min',
                    tinymce: 'tiny_mce_5/tinymce.min',
                    wysiwygAdapter: 'mage/adminhtml/wysiwyg/tiny_mce/tinymce5Adapter'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            deps: ['Magento_Ui/js/core/app']
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    pageCache: 'Magento_PageCache/js/page-cache'
                }
            },
            deps: ['Magento_PageCache/js/form-key-provider']
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    captcha: 'Magento_Captcha/js/captcha',
                    'Magento_Captcha/captcha': 'Magento_Captcha/js/captcha'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    configurable: 'Magento_ConfigurableProduct/js/configurable'
                }
            },
            config: {
                mixins: {
                    'Magento_Catalog/js/catalog-add-to-cart': {
                        'Magento_ConfigurableProduct/js/catalog-add-to-cart-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    multiShipping: 'Magento_Multishipping/js/multi-shipping',
                    orderOverview: 'Magento_Multishipping/js/overview',
                    payment: 'Magento_Multishipping/js/payment',
                    billingLoader: 'Magento_Checkout/js/checkout-loader',
                    cartUpdate: 'Magento_Checkout/js/action/update-shopping-cart',
                    multiShippingBalance: 'Magento_Multishipping/js/multi-shipping-balance'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    recentlyViewedProducts: 'Magento_Reports/js/recently-viewed'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    subscriptionStatusResolver: 'Magento_Newsletter/js/subscription-status-resolver',
                    newsletterSignUp: 'Magento_Newsletter/js/newsletter-sign-up'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Magento_Checkout/js/action/select-payment-method': {
                        'Magento_SalesRule/js/action/select-payment-method-mixin': true
                    },
                    'Magento_Checkout/js/model/shipping-save-processor': {
                        'Magento_SalesRule/js/model/shipping-save-processor-mixin': true
                    },
                    'Magento_Checkout/js/action/place-order': {
                        'Magento_SalesRule/js/model/place-order-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    'slick': 'Magento_PageBuilder/js/resource/slick/slick',
                    'jarallax': 'Magento_PageBuilder/js/resource/jarallax/jarallax',
                    'jarallaxVideo': 'Magento_PageBuilder/js/resource/jarallax/jarallax-video',
                    'Magento_PageBuilder/js/resource/vimeo/player': 'vimeo/player',
                    'Magento_PageBuilder/js/resource/vimeo/vimeo-wrapper': 'vimeo/vimeo-wrapper',
                    'jarallax-wrapper': 'Magento_PageBuilder/js/resource/jarallax/jarallax-wrapper'
                }
            },
            shim: {
                'Magento_PageBuilder/js/resource/slick/slick': {
                    deps: ['jquery']
                },
                'Magento_PageBuilder/js/resource/jarallax/jarallax-video': {
                    deps: ['jarallax-wrapper', 'vimeoWrapper']
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            shim: {
                cardinaljs: {
                    exports: 'Cardinal'
                },
                cardinaljsSandbox: {
                    exports: 'Cardinal'
                }
            },
            paths: {
                cardinaljsSandbox: 'https://includestest.ccdc02.com/cardinalcruise/v1/songbird',
                cardinaljs: 'https://songbird.cardinalcommerce.com/edge/v1/songbird'
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    transparent: 'Magento_Payment/js/transparent',
                    'Magento_Payment/transparent': 'Magento_Payment/js/transparent'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    orderReview: 'Magento_Paypal/js/order-review',
                    'Magento_Paypal/order-review': 'Magento_Paypal/js/order-review',
                    paypalCheckout: 'Magento_Paypal/js/paypal-checkout'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Magento_Customer/js/customer-data': {
                        'Magento_Persistent/js/view/customer-data-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    loadPlayer: 'Magento_ProductVideo/js/load-player',
                    fotoramaVideoEvents: 'Magento_ProductVideo/js/fotorama-add-video-events',
                    'vimeoWrapper': 'vimeo/vimeo-wrapper'
                }
            },
            shim: {
                vimeoAPI: {},
                'Magento_ProductVideo/js/load-player': {
                    deps: ['vimeoWrapper']
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Magento_Checkout/js/action/place-order': {
                        'Magento_CheckoutAgreements/js/model/place-order-mixin': true
                    },
                    'Magento_Checkout/js/action/set-payment-information': {
                        'Magento_CheckoutAgreements/js/model/set-payment-information-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Magento_Checkout/js/model/place-order': {
                        'Magento_ReCaptchaCheckout/js/model/place-order-mixin': true
                    },
                    'Magento_ReCaptchaWebapiUi/js/webapiReCaptchaRegistry': {
                        'Magento_ReCaptchaCheckout/js/webapiReCaptchaRegistry-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        'use strict';
        var config = {
            config: {
                mixins: {
                    'Magento_Ui/js/view/messages': {
                        'Magento_ReCaptchaFrontendUi/js/ui-messages-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Magento_Paypal/js/view/payment/method-renderer/payflowpro-method': {
                        'Magento_ReCaptchaPaypal/js/payflowpro-method-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'jquery': {
                        'Magento_ReCaptchaWebapiUi/js/jquery-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    mageTranslationDictionary: 'Magento_Translation/js/mage-translation-dictionary'
                }
            },
            deps: ['mageTranslationDictionary']
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    editTrigger: 'mage/edit-trigger',
                    addClass: 'Magento_Translation/js/add-class',
                    'Magento_Translation/add-class': 'Magento_Translation/js/add-class'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Magento_Checkout/js/view/payment/list': {
                        'Magento_PaypalCaptcha/js/view/payment/list-mixin': true
                    },
                    'Magento_Paypal/js/view/payment/method-renderer/payflowpro-method': {
                        'Magento_PaypalCaptcha/js/view/payment/method-renderer/payflowpro-method-mixin': true
                    },
                    'Magento_Captcha/js/view/checkout/defaultCaptcha': {
                        'Magento_PaypalCaptcha/js/view/checkout/defaultCaptcha-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    'taxToggle': 'Magento_Weee/js/tax-toggle',
                    'Magento_Weee/tax-toggle': 'Magento_Weee/js/tax-toggle'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    wishlist: 'Magento_Wishlist/js/wishlist',
                    addToWishlist: 'Magento_Wishlist/js/add-to-wishlist',
                    wishlistSearch: 'Magento_Wishlist/js/search'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            paths: {
                quickDevBar: 'ADM_QuickDevBar/js/quickdevbar',
                filtertable: 'ADM_QuickDevBar/js/sunnywalker/jquery.filtertable.min',
                metadata: 'ADM_QuickDevBar/js/tablesorter/jquery.metadata',
                tablesorter: 'ADM_QuickDevBar/js/tablesorter/jquery.tablesorter.min',
                jqueryTabs: ['jquery-ui-modules/tabs', 'jquery/jquery-ui']
            },
            shim: {
                'quickDevBar': {
                    deps: ['jquery']
                },
                'filtertable': {
                    deps: ['jquery']
                },
                'metadata': {
                    deps: ['jquery']
                },
                'tablesorter': {
                    deps: ['jquery']
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    'amrevloader': 'Amasty_AdvancedReview/js/components/amrev-loader',
                    'amReview': 'Amasty_AdvancedReview/js/amReview',
                    'amSummaryInfo': 'Amasty_AdvancedReview/js/widget/amSummaryInfo',
                    'amReviewSlider': 'Amasty_AdvancedReview/js/widget/amReviewSlider',
                    'amImageSlider': 'Amasty_AdvancedReview/js/widget/amImageSlider',
                    'amProductReviews': 'Amasty_AdvancedReview/js/widget/amProductReviews',
                    'amShowMore': 'Amasty_AdvancedReview/js/components/am-show-more'
                }
            },
            config: {
                mixins: {
                    'Magento_Review/js/view/review': {
                        'Amasty_AdvancedReview/js/view/review': true
                    }
                }
            },
            shim: {
                'Magento_Review/js/process-reviews': ['mage/tabs']
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Magento_Checkout/js/model/shipping-rates-validation-rules': {
                        'Amasty_Conditions/js/model/shipping-rates-validation-rules-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var amasty_mixin_enabled = !window.amasty_checkout_disabled,
            config;
        config = {
            'map': {
                '*': {}
            },
            config: {
                mixins: {
                    'Magento_Checkout/js/model/new-customer-address': {
                        'Amasty_CheckoutCore/js/model/new-customer-address-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/view/payment/list': {
                        'Amasty_CheckoutCore/js/view/payment/list': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/view/summary/abstract-total': {
                        'Amasty_CheckoutCore/js/view/summary/abstract-total': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/model/step-navigator': {
                        'Amasty_CheckoutCore/js/model/step-navigator-mixin': amasty_mixin_enabled
                    },
                    'Magento_Paypal/js/action/set-payment-method': {
                        'Amasty_CheckoutCore/js/action/set-payment-method-mixin': amasty_mixin_enabled
                    },
                    'Magento_CheckoutAgreements/js/model/agreements-assigner': {
                        'Amasty_CheckoutCore/js/model/agreements-assigner-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/view/summary': {
                        'Amasty_CheckoutCore/js/view/summary-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/view/shipping': {
                        'Amasty_CheckoutCore/js/view/shipping-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/view/summary/cart-items': {
                        'Amasty_CheckoutCore/js/view/summary/cart-items-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/model/payment/additional-validators': {
                        'Amasty_CheckoutCore/js/model/payment-validators/additional-validators-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/model/customer-email-validator': {
                        'Amasty_CheckoutCore/js/model/customer-email-validator-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/model/checkout-data-resolver': {
                        'Amasty_CheckoutCore/js/model/checkout-data-resolver-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/model/shipping-rates-validator': {
                        'Amasty_CheckoutCore/js/model/shipping-rates-validator-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/action/set-shipping-information': {
                        'Amasty_CheckoutCore/js/action/set-shipping-information-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/model/full-screen-loader': {
                        'Amasty_CheckoutCore/js/model/full-screen-loader-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/model/shipping-rate-processor/new-address': {
                        'Amasty_CheckoutCore/js/model/default-shipping-rate-processor-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/view/payment': {
                        'Amasty_CheckoutCore/js/view/payment-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/model/payment-service': {
                        'Amasty_CheckoutCore/js/model/payment-service-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/model/address-converter': {
                        'Amasty_CheckoutCore/js/model/address-converter-mixin': amasty_mixin_enabled
                    },
                    'Magento_Paypal/js/view/payment/method-renderer/in-context/checkout-express': {
                        'Amasty_CheckoutCore/js/view/payment/method-renderer/in-context/checkout-express-mixin': amasty_mixin_enabled
                    },
                    'Magento_Braintree/js/view/payment/method-renderer/paypal': {
                        'Amasty_CheckoutCore/js/view/payment/method-renderer/braintree/paypal-mixin': amasty_mixin_enabled
                    },
                    'PayPal_Braintree/js/view/payment/method-renderer/paypal': {
                        'Amasty_CheckoutCore/js/view/payment/method-renderer/braintree/paypal-mixin': amasty_mixin_enabled
                    },
                    'Magento_Braintree/js/view/payment/method-renderer/cc-form': {
                        'Amasty_CheckoutCore/js/view/payment/method-renderer/braintree/cc-form-mixin': amasty_mixin_enabled
                    },
                    'PayPal_Braintree/js/view/payment/method-renderer/cc-form': {
                        'Amasty_CheckoutCore/js/view/payment/method-renderer/braintree/cc-form-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/view/billing-address': {
                        'Amasty_CheckoutCore/js/view/billing-address-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/view/payment/default': {
                        'Amasty_CheckoutCore/js/view/payment/method-renderer/default-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/model/shipping-rate-registry': {
                        'Amasty_CheckoutCore/js/model/shipping-rate-registry-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/view/shipping-address/address-renderer/default': {
                        'Amasty_CheckoutCore/js/view/shipping-address/address-renderer/default-mixin': amasty_mixin_enabled
                    },
                    'Amasty_Gdpr/js/model/consents-assigner': {
                        'Amasty_CheckoutCore/js/model/consents-assigner-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/action/select-payment-method': {
                        'Magento_SalesRule/js/action/select-payment-method-mixin': !amasty_mixin_enabled
                    }
                }
            }
        };
        if (amasty_mixin_enabled) {
            config.map['*'] = {
                checkoutCollapsibleSteps: 'Amasty_CheckoutCore/js/view/checkout/design/collapsible-steps',
                summaryWidget: 'Amasty_CheckoutCore/js/view/summary/summary-widget',
                stickyWidget: 'Amasty_CheckoutCore/js/view/summary/sticky-widget',
                'Magento_Checkout/template/payment-methods/list.html': 'Amasty_CheckoutCore/template/payment-methods/list.html',
                'Magento_Checkout/template/billing-address/details.html': 'Amasty_CheckoutCore/template/onepage/billing-address/details.html',
                'Magento_Checkout/js/action/get-totals': 'Amasty_CheckoutCore/js/action/get-totals',
                'Magento_Checkout/js/model/shipping-rate-service': 'Amasty_CheckoutCore/js/model/shipping-rate-service-override',
                'Magento_Checkout/js/action/recollect-shipping-rates': 'Amasty_CheckoutCore/js/action/recollect-shipping-rates'
            };
        }
        require.config(config);
    })();
    (function() {
        var amasty_mixin_enabled = !window.amasty_checkout_disabled,
            config;
        config = {
            config: {
                mixins: {
                    'Magento_Checkout/js/view/billing-address': {
                        'Amasty_Checkout/js/view/billing-address-mixin': amasty_mixin_enabled
                    },
                    'Magento_Checkout/js/view/shipping': {
                        'Amasty_Checkout/js/view/shipping-mixin': amasty_mixin_enabled
                    }
                }
            },
            shim: {
                'Amasty_CheckoutCore/js/view/onepage': ['Amasty_Checkout/js/validation/phone-validation']
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    amCodCheckAvailable: 'Amasty_CashOnDelivery/js/checkAvailable'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Magento_Paypal/js/view/payment/method-renderer/in-context/checkout-express': {
                        'Amasty_InvisibleCaptcha/js/view/paypal/in-context/checkout-express-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Amasty_Conf/js/swatch-renderer': {
                        'Amasty_Label/js/configurable/swatch-renderer': true
                    },
                    'Magento_Swatches/js/swatch-renderer': {
                        'Amasty_Label/js/configurable/swatch-renderer': true
                    },
                    'Amasty_Conf/js/configurable': {
                        'Amasty_Label/js/configurable/configurable': true
                    },
                    'Magento_ConfigurableProduct/js/configurable': {
                        'Amasty_Label/js/configurable/configurable': true
                    }
                }
            },
            map: {
                '*': {
                    amInitLabelUi: 'Amasty_Label/js/uiWidget/amLoadUiLabel'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Amasty_Conf/js/swatch-renderer': {
                        'Amasty_Mostviewed/js/swatch-renderer': true
                    },
                    'Magento_Swatches/js/swatch-renderer': {
                        'Amasty_Mostviewed/js/swatch-renderer': false
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    'Magento_SalesRule/js/action/select-payment-method-mixin': 'Amasty_Payrestriction/js/action/select-payment-method-mixin'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Magento_Checkout/js/view/summary/item/details/thumbnail': {
                        'Amasty_Promo/js/checkout/sidebar-image-update': true
                    },
                    'Magento_Checkout/js/view/summary/cart-items': {
                        'Amasty_Promo/js/checkout/cart-items-counter-update': true
                    },
                    'Magento_Theme/js/view/messages': {
                        'Amasty_Promo/js/view/messages': true
                    },
                    'Amasty_Coupons/js/model/cart/apply-response-processor': {
                        'Amasty_Promo/js/model/coupon-apply-response-processor-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Magento_Checkout/js/model/shipping-rates-validation-rules': {
                        'Amasty_Shiprestriction/js/model/shipping-rates-validation-rules-mixin': true
                    },
                    'Magento_Checkout/js/view/shipping': {
                        'Amasty_Shiprestriction/js/view/shipping-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    amShopbyTooltipInit: 'Amasty_ShopbyBase/js/components/am-tooltip-init'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    'amshopby_color': 'Amasty_Shopby/js/utils/color'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    amShopbyFilterAbstract: 'Amasty_Shopby/js/amShopby',
                    amShopbyResponsive: 'Amasty_Shopby/js/amShopbyResponsive',
                    amShopbyFilterItemDefault: 'Amasty_Shopby/js/components/amShopbyFilterItemDefault',
                    amShopbyFilterDropdown: 'Amasty_Shopby/js/components/amShopbyFilterDropdown',
                    amShopbyFilterFromTo: 'Amasty_Shopby/js/components/amShopbyFilterFromTo',
                    amShopbyFilterHideMoreOptions: 'Amasty_Shopby/js/components/amShopbyFilterHideMoreOptions',
                    amShopbyFilterAddTooltip: 'Amasty_Shopby/js/components/amShopbyFilterAddTooltip',
                    amShopbyFilterCategoryDropdown: 'Amasty_Shopby/js/components/amShopbyFilterCategoryDropdown',
                    amShopbyFilterCategory: 'Amasty_Shopby/js/components/amShopbyFilterCategory',
                    amShopbyFilterContainer: 'Amasty_Shopby/js/components/amShopbyFilterContainer',
                    amShopbyFilterSearch: 'Amasty_Shopby/js/components/amShopbyFilterSearch',
                    amShopbyFilterMultiselect: 'Amasty_Shopby/js/components/amShopbyFilterMultiselect',
                    amShopbyFilterSwatch: 'Amasty_Shopby/js/components/amShopbyFilterSwatch',
                    amShopbyFilterSlider: 'Amasty_Shopby/js/components/amShopbyFilterSlider',
                    amShopbyFilterFlyout: 'Amasty_Shopby/js/components/amShopbyFilterFlyout',
                    amShopbySwiperSlider: 'Amasty_Shopby/js/components/amShopbySwiperSlider',
                    amShopbySwatchTooltip: 'Amasty_Shopby/js/components/amShopbySwatchTooltip',
                    amShopbyStickySidebar: 'Amasty_Shopby/js/components/amShopbyStickySidebar',
                    amShopbyFilterCollapse: 'Amasty_Shopby/js/components/amShopbyFilterCollapse',
                    amShopbySwatchesChoose: 'Amasty_Shopby/js/amShopbySwatchesChoose',
                    amShopbyFiltersSync: 'Amasty_Shopby/js/amShopbyFiltersSync',
                    amShopbyApplyFilters: 'Amasty_Shopby/js/amShopbyApplyFilters',
                    amShopbyTopFilters: 'Amasty_Shopby/js/amShopbyTopFilters',
                    amShopbyAjax: 'Amasty_Shopby/js/amShopbyAjax',
                    amShopbyHelpers: 'Amasty_Shopby/js/utils/helpers',
                    swiper: 'Amasty_LibSwiperJs/js/vendor/swiper/swiper.min'
                }
            },
            config: {
                mixins: {
                    'jquery/ui-modules/widgets/slider': {
                        'Amasty_Shopby/js/mixins/slider': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    amBrandsSearch: 'Amasty_ShopbyBrand/js/components/ambrands-search',
                    amBrandsFilterInit: 'Amasty_ShopbyBrand/js/components/ambrands-filter-init',
                    amBrandsFilter: 'Amasty_ShopbyBrand/js/brand-filter',
                    swiper: 'Amasty_LibSwiperJs/js/vendor/swiper/swiper.min'
                }
            },
            config: {
                mixins: {
                    'mage/menu': {
                        'Amasty_ShopbyBrand/js/lib/mage/ambrands-menu-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'mage/validation': {
                        'Amasty_Xnotif/js/validation-mixin': false,
                        'Amasty_SocialLogin/js/validation-mixin': true
                    },
                    'Magento_Customer/js/model/authentication-popup': {
                        'Amasty_SocialLogin/js/authentication-popup-mixin': true
                    },
                    'Magento_Checkout/js/view/progress-bar': {
                        'Amasty_SocialLogin/js/mixins/magento_checkout/view/progress-bar': true
                    },
                    'Amasty_Faq/js/rating/yes-no-voting': {
                        'Amasty_SocialLogin/js/mixins/amfaq/rating/amsl-yes-no-voting': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    amnotification: 'Amasty_Xnotif/js/amnotification',
                    'productSummary': 'Amasty_Xnotif/js/bundle/product-summary',
                    'magento-bundle.product-summary': 'Magento_Bundle/js/product-summary'
                }
            },
            deps: ['Magento_ConfigurableProduct/js/configurable'],
            config: {
                mixins: {
                    'mage/validation': {
                        'Amasty_Xnotif/js/validation-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Magento_Swatches/js/swatch-renderer': {
                        'BKozlic_ConfigurableOptions/js/swatch-renderer-mixin': true
                    },
                    'Magento_ConfigurableProduct/js/configurable': {
                        'BKozlic_ConfigurableOptions/js/configurable-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    initpopup: 'Bss_Popup/js/initpopup',
                    renderpopup: 'Bss_Popup/js/renderpopup'
                }
            },
            paths: {
                'mfpopup': 'Bss_Popup/js/mfpopup'
            },
            shim: {
                'mfpopup': {
                    'deps': ['jquery']
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    pushnotification: 'Bss_PushNotification/js/pushnotification'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    framesjs: 'https://cdn.checkout.com/js/framesv2.min.js',
                    Klarna: 'https://x.klarnacdn.net/kp/lib/v1/api.js',
                    googlepayjs: 'https://pay.google.com/gp/p/js/pay.js'
                }
            },
            config: {
                mixins: {
                    'Magento_Checkout/js/model/checkout-data-resolver': {
                        'CheckoutCom_Magento2/js/model/checkout-data-resolver': true
                    },
                    'Magento_Tax/js/view/checkout/summary/grand-total': {
                        'CheckoutCom_Magento2/js/model/grand-total-hide': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            'map': {
                '*': {
                    'slick': 'Gurubhyo_Personalized/js/slickjs',
                    'slick-min': 'Gurubhyo_Personalized/js/slick.min',
                    'Magento_OfflinePayments/js/view/payment/method-renderer/cashondelivery-method': 'Gurubhyo_Personalized/js/payment/method-renderer/payment/method-renderer/cashondelivery-method'
                }
            },
            'shim': {
                'Gurubhyo_Personalized/js/slick.min': ['jquery']
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            paths: {
                'leanport/zoom': 'Leanport_Zoom/js/photoswipe',
                'leanport/zoom_ui': 'Leanport_Zoom/js/photoswipe-ui-default',
                "boostrap3": "Leanport_Zoom/js/boostrap3/bootstrap"
            },
            shim: {
                'leanport/zoom': {
                    deps: ['jquery']
                },
                'boostrap3': {
                    deps: ['jquery']
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    'Magento_Catalog/js/price-utils': 'Lillik_PriceDecimal/js/price-utils'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    storelocator: 'MGS_StoreLocator/js/storelocator'
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    cityUpdater: 'MagePsycho_RegionCityPro/js/city-updater',
                    select2: 'MagePsycho_RegionCityPro/js/select2.min'
                }
            },
            config: {
                mixins: {
                    'Magento_Checkout/js/action/create-shipping-address': {
                        'MagePsycho_RegionCityPro/js/action/create-shipping-address-mixin': true
                    },
                    'Magento_Checkout/js/action/select-shipping-address': {
                        'MagePsycho_RegionCityPro/js/action/select-shipping-address-mixin': true
                    },
                    'Magento_Checkout/js/action/set-shipping-information': {
                        'MagePsycho_RegionCityPro/js/action/set-shipping-information-mixin': true
                    },
                    'Magento_Checkout/js/action/select-billing-address': {
                        'MagePsycho_RegionCityPro/js/action/select-billing-address-mixin': true
                    },
                    'Magento_Checkout/js/action/set-payment-information': {
                        'MagePsycho_RegionCityPro/js/action/set-payment-information-mixin': true
                    },
                    'Magento_Checkout/js/view/billing-address': {
                        'MagePsycho_RegionCityPro/js/view/billing-address-mixin': true
                    },
                    'Magento_Checkout/js/view/shipping-address/address-renderer/default': {
                        'MagePsycho_RegionCityPro/js/view/shipping-address/address-renderer/default-mixin': true
                    },
                    'Magento_Checkout/js/view/shipping-information/address-renderer/default': {
                        'MagePsycho_RegionCityPro/js/view/shipping-information/address-renderer/default-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            paths: {
                'mageplaza/core/jquery/popup': 'Mageplaza_Core/js/jquery.magnific-popup.min',
                'mageplaza/core/owl.carousel': 'Mageplaza_Core/js/owl.carousel.min',
                'mageplaza/core/bootstrap': 'Mageplaza_Core/js/bootstrap.min',
                mpIonRangeSlider: 'Mageplaza_Core/js/ion.rangeSlider.min',
                touchPunch: 'Mageplaza_Core/js/jquery.ui.touch-punch.min',
                mpDevbridgeAutocomplete: 'Mageplaza_Core/js/jquery.autocomplete.min'
            },
            shim: {
                "mageplaza/core/jquery/popup": ["jquery"],
                "mageplaza/core/owl.carousel": ["jquery"],
                "mageplaza/core/bootstrap": ["jquery"],
                mpIonRangeSlider: ["jquery"],
                mpDevbridgeAutocomplete: ["jquery"],
                touchPunch: ['jquery', 'jquery-ui-modules/core', 'jquery-ui-modules/mouse', 'jquery-ui-modules/widget']
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            paths: {
                comment: 'Mageplaza_Blog/js/comment',
                categoryTree: 'Mageplaza_Blog/js/categorytree',
                owlCarousel: 'Mageplaza_Core/js/owl.carousel.min'
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {};
        if (typeof window.AVADA_EM !== 'undefined') {
            config = {
                config: {
                    mixins: {
                        'Magento_Checkout/js/view/billing-address': {
                            'Mageplaza_Smtp/js/view/billing-address-mixins': true
                        },
                        'Magento_Checkout/js/view/shipping': {
                            'Mageplaza_Smtp/js/view/shipping-mixins': true
                        }
                    }
                }
            };
        }
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    'easing': 'magepow/easing',
                    'slick': 'magepow/slick',
                    'gridSlider': 'magepow/grid-slider',
                },
            },
            paths: {
                'magepow/easing': 'Magepow_Core/js/plugin/jquery.easing.min',
                'magepow/slick': 'Magepow_Core/js/plugin/slick.min',
                'magepow/grid-slider': 'Magepow_Core/js/grid-slider',
            },
            shim: {
                'magepow/easing': {
                    deps: ['jquery']
                },
                'magepow/slick': {
                    deps: ['jquery']
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    infinitescroll: 'Magepow_InfiniteScroll/js/plugin/infinitescroll',
                }
            },
            paths: {
                'magepow/infinitescroll': 'Magepow_InfiniteScroll/js/plugin/infinitescroll',
            },
            shim: {
                'magepow/infinitescroll': {
                    deps: ['jquery']
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            paths: {
                "intlTelInput": 'MaxMage_InternationalTelephoneInput/js/intlTelInput',
                "intlTelInputUtils": 'MaxMage_InternationalTelephoneInput/js/utils',
                "internationalTelephoneInput": 'MaxMage_InternationalTelephoneInput/js/internationalTelephoneInput'
            },
            shim: {
                'intlTelInput': {
                    'deps': ['jquery', 'knockout']
                },
                'internationalTelephoneInput': {
                    'deps': ['jquery', 'intlTelInput']
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            paths: {
                'owl.carousel': 'Olegnax_Core/owl.carousel/owl.carousel.min',
                'OXowlCarousel': 'Olegnax_Core/owl.carousel'
            },
            shim: {
                'owl.carousel': {
                    deps: ['jquery', 'jquery-ui-modules/widget']
                }
            }
        };
        if (OX_OWL_DISABLE) {
            delete config.paths['owl.carousel'];
            delete config.paths['OXowlCarousel'];
            delete config.shim['owl.carousel'];
        }
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    'oxFormValues': 'Olegnax_InfiniteScrollPro/js/form-values',
                    'OxInfiniteScroll': 'Olegnax_InfiniteScrollPro/js/scroll',
                }
            },
            config: {
                mixins: {
                    'Magento_Swatches/js/swatch-renderer': {
                        'Olegnax_InfiniteScrollPro/js/swatch-renderer': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    "payfort_fort": 'Payfort_Fort/js/payfort_fort'
                }
            },
            shim: {
                "payfort_fort": {
                    deps: ['jquery']
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Magento_Ui/js/lib/validation/validator': {
                        'RG_CustomCheckoutField/js/streetValidation': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Magento_Swatches/js/swatch-renderer': {
                        'Tabby_Checkout/js/mixin/swatch-renderer': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            config: {
                mixins: {
                    'Magento_ReCaptchaFrontendUi/js/reCaptcha': {
                        'VendorFix_ReCaptchaFrontendUi/js/recaptcha-mixin': true
                    }
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            map: {
                '*': {
                    vesallOwlCarousel: 'Ves_All/lib/owl.carousel/owl.carousel.min',
                    vesallBootstrap: 'Ves_All/lib/bootstrap/js/bootstrap.min',
                    vesallColorbox: 'Ves_All/lib/colorbox/jquery.colorbox.min',
                    vesallFancybox: 'Ves_All/lib/fancybox/jquery.fancybox.pack',
                    vesallBootstrap4: 'Ves_All/lib/bootstrap4/js/bootstrap.min',
                    'popper.js': 'Ves_All/lib/bootstrap4/js/popper.min',
                    vesallFancyboxMouseWheel: 'Ves_All/lib/fancybox/jquery.mousewheel-3.0.6.pack'
                }
            },
            shim: {
                'Ves_All/lib/bootstrap/js/bootstrap.min': {
                    'deps': ['jquery']
                },
                'Ves_All/lib/bootstrap4/js/bootstrap.min': {
                    'deps': ['jquery']
                },
                'Ves_All/lib/bootstrap4/js/popper.min': {
                    'deps': ['jquery']
                },
                'Ves_All/lib/bootstrap/js/bootstrap': {
                    'deps': ['jquery']
                },
                'Ves_All/lib/owl.carousel/owl.carousel': {
                    'deps': ['jquery']
                },
                'Ves_All/lib/owl.carousel/owl.carousel.min': {
                    'deps': ['jquery']
                },
                'Ves_All/lib/fancybox/jquery.fancybox': {
                    'deps': ['jquery']
                },
                'Ves_All/lib/fancybox/jquery.fancybox.pack': {
                    'deps': ['jquery']
                },
                'Ves_All/lib/colorbox/jquery.colorbox': {
                    'deps': ['jquery']
                },
                'Ves_All/lib/colorbox/jquery.colorbox.min': {
                    'deps': ['jquery']
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            paths: {
                "menu.bootstrap": "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min",
                "scrolltofixed": "Ves_Megamenu/js/jquery-scrolltofixed-min",
                "megamenuowlcarousel": "Ves_All/lib/owl.carousel/owl.carousel.min",
                "megamenuGeneral": "Ves_Megamenu/js/megamenuGeneral"
            },
            shim: {
                'menu.bootstrap': {
                    'deps': ['jquery']
                },
                'scrolltofixed': {
                    'deps': ['jquery']
                },
                'megamenuowlcarousel': {
                    'deps': ['jquery']
                },
                'megamenuGeneral': {
                    'deps': ['jquery']
                },
                'Ves_Megamenu/js/megamenuGeneral': {
                    'deps': ['jquery']
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            deps: ['Magento_Theme/js/theme']
        };
        require.config(config);
    })();
    (function() {
        var config = {
            paths: {
                'owlcarousel': "js/owlcarousel"
            },
            shim: {
                'owlcarousel': {
                    deps: ['jquery']
                }
            }
        };
        require.config(config);
    })();
    (function() {
        var config = {
            deps: ["js/main"],
            paths: {
                "jquery.boxslider": "https://cdnjs.cloudflare.com/ajax/libs/bxslider/4.2.12/jquery.bxslider.min",
                "select2": "https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min",
                "owlcarousel": "js/owl.carousel.min",
                "jstree": "js/jstree.min",
                "flexslider": "js/flexslider.min",
                "fancybox": "js/jquery.fancybox",
                "collapse": "js/bootstrap/collapse",
                "jquery.bootstrap": "js/bootstrap/bootstrap.bundle",
            },
            shim: {
                'jquery.boxslider': {
                    'deps': ['jquery']
                },
                'select2': {
                    'deps': ['jquery']
                },
                'owlcarousel': {
                    'deps': ['jquery']
                },
                'flexslider': {
                    'deps': ['jquery']
                },
                'fancybox': {
                    'deps': ['jquery']
                },
                'slick': {
                    'deps': ['jquery']
                },
                'collapse': {
                    'deps': ['jquery']
                },
                'jquery.bootstrap': {
                    'deps': ['jquery']
                }
            }
        };
        require.config(config);
    })();
})(require);