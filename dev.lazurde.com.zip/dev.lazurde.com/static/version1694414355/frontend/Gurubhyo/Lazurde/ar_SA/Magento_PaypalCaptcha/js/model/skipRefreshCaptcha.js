define(['ko'], function(ko) {
    'use strict';
    return {
        skip: ko.observable(false)
    };
});