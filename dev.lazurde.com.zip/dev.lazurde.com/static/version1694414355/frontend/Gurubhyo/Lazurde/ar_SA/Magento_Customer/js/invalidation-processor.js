define(['underscore', 'uiElement', 'Magento_Customer/js/customer-data'], function(_, Element, customerData) {
    'use strict';
    return Element.extend({
        initialize: function() {
            this._super();
            this.process(customerData);
        },
        process: function(customerDataObject) {
            _.each(this.invalidationRules, function(rule, ruleName) {
                _.each(rule, function(ruleArgs, rulePath) {
                    require([rulePath], function(Rule) {
                        var currentRule = new Rule(ruleArgs);
                        if (!_.isFunction(currentRule.process)) {
                            throw new Error('Rule ' + ruleName + ' should implement invalidationProcessor interface');
                        }
                        currentRule.process(customerDataObject);
                    });
                });
            });
        }
    });
});