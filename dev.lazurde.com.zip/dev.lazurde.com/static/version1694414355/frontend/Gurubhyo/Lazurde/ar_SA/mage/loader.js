define(['jquery', 'mage/template', 'jquery-ui-modules/widget', 'mage/translate'], function($, mageTemplate) {
    'use strict';
    $.widget('mage.loader', {
        loaderStarted: 0,
        options: {
            icon: '',
            texts: {
                loaderText: $.mage.__('Please wait...'),
                imgAlt: $.mage.__('Loading...')
            },
            template: '<div class="loading-mask" data-role="loader">' +
                '<div class="loader">' +
                '<img alt="<%- data.texts.imgAlt %>" src="<%- data.icon %>">' +
                '<p><%- data.texts.loaderText %></p>' +
                '</div>' +
                '</div>'
        },
        _create: function() {
            this._bind();
        },
        _bind: function() {
            this._on({
                'processStop': 'hide',
                'processStart': 'show',
                'show.loader': 'show',
                'hide.loader': 'hide',
                'contentUpdated.loader': '_contentUpdated'
            });
        },
        _contentUpdated: function(e) {
            this.show(e);
        },
        show: function(e, ctx) {
            this._render();
            this.loaderStarted++;
            this.spinner.show();
            if (ctx) {
                this.spinner.css({
                    width: ctx.outerWidth(),
                    height: ctx.outerHeight(),
                    position: 'absolute'
                }).position({
                    my: 'top left',
                    at: 'top left',
                    of: ctx
                });
            }
            return false;
        },
        hide: function() {
            if (this.loaderStarted > 0) {
                this.loaderStarted--;
                if (this.loaderStarted === 0) {
                    this.spinner.hide();
                }
            }
            return false;
        },
        _render: function() {
            var html;
            if (!this.spinnerTemplate) {
                this.spinnerTemplate = mageTemplate(this.options.template);
                html = $(this.spinnerTemplate({
                    data: this.options
                }));
                html.prependTo(this.element);
                this.spinner = html;
            }
        },
        _destroy: function() {
            this.spinner.remove();
        }
    });
    $.widget('mage.loaderAjax', {
        options: {
            defaultContainer: '[data-container=body]',
            loadingClass: 'ajax-loading'
        },
        _create: function() {
            this._bind();
            if (window.console && !this.element.is(this.options.defaultContainer) && $.mage.isDevMode(undefined)) {
                console.warn('This widget is intended to be attached to the body, not below.');
            }
        },
        _bind: function() {
            $(document).on({
                'ajaxSend': this._onAjaxSend.bind(this),
                'ajaxComplete': this._onAjaxComplete.bind(this)
            });
        },
        _getJqueryObj: function(loaderContext) {
            var ctx;
            if (loaderContext) {
                if (loaderContext.jquery) {
                    ctx = loaderContext;
                } else {
                    ctx = $(loaderContext);
                }
            } else {
                ctx = $('[data-container="body"]');
            }
            return ctx;
        },
        _onAjaxSend: function(e, jqxhr, settings) {
            var ctx;
            $(this.options.defaultContainer).addClass(this.options.loadingClass).attr({
                'aria-busy': true
            });
            if (settings && settings.showLoader) {
                ctx = this._getJqueryObj(settings.loaderContext);
                ctx.trigger('processStart');
                if (window.console && !ctx.parents('[data-role="loader"]').length) {
                    console.warn('Expected to start loader but did not find one in the dom');
                }
            }
        },
        _onAjaxComplete: function(e, jqxhr, settings) {
            $(this.options.defaultContainer).removeClass(this.options.loadingClass).attr('aria-busy', false);
            if (settings && settings.showLoader) {
                this._getJqueryObj(settings.loaderContext).trigger('processStop');
            }
        }
    });
    return {
        loader: $.mage.loader,
        loaderAjax: $.mage.loaderAjax
    };
});