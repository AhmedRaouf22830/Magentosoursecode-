define(['ko', './customer-addresses'], function(ko, defaultProvider) {
    'use strict';
    return ko.observableArray(defaultProvider.getAddressItems());
});