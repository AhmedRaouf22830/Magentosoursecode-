define(['text!js-translation.json'], function(dict) {
    'use strict';
    return JSON.parse(dict);
});