define(['ko', 'jquery', 'uiComponent', '../model/messageList', 'jquery-ui-modules/effect-blind'], function(ko, $, Component, globalMessages) {
    'use strict';
    return Component.extend({
        defaults: {
            template: 'Magento_Ui/messages',
            selector: '[data-role=checkout-messages]',
            isHidden: false,
            hideTimeout: 5000,
            hideSpeed: 500,
            listens: {
                isHidden: 'onHiddenChange'
            }
        },
        initialize: function(config, messageContainer) {
            this._super().initObservable();
            this.messageContainer = messageContainer || config.messageContainer || globalMessages;
            return this;
        },
        initObservable: function() {
            this._super().observe('isHidden');
            return this;
        },
        isVisible: function() {
            return this.isHidden(this.messageContainer.hasMessages());
        },
        removeAll: function() {
            this.messageContainer.clear();
        },
        onHiddenChange: function(isHidden) {
            if (isHidden) {
                setTimeout(function() {
                    $(this.selector).hide('slow');
                }.bind(this), this.hideTimeout);
            }
        }
    });
});