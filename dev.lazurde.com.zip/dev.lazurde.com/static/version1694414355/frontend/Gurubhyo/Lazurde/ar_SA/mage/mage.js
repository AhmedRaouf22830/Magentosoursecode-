define(['jquery', 'mage/apply/main'], function($, mage) {
    'use strict';
    $.mage = $.mage || {};
    $.fn.mage = function(name, config) {
        config = config || {};
        this.each(function(index, el) {
            mage.applyFor(el, config, name);
        });
        return this;
    };
    $.extend($.mage, {
        init: function() {
            mage.apply();
            return this;
        },
        redirect: function(url, type, timeout, forced) {
            var _redirect;
            forced = !!forced;
            timeout = timeout || 0;
            type = type || 'assign';
            _redirect = function() {
                window.location[type](type === 'reload' ? forced : url);
            };
            timeout ? setTimeout(_redirect, timeout) : _redirect();
        },
        isValidSelector: function(selector) {
            try {
                document.querySelector(selector);
                return true;
            } catch (e) {
                return false;
            }
        }
    });
    $(document).on('contentUpdated', 'body', function() {
        if (mage) {
            mage.apply();
        }
    });
    return $.mage;
});