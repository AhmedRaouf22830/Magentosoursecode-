(function(factory) {
    "use strict";
    if (typeof define === "function" && define.amd) {
        define(["jquery"], factory);
    } else {
        factory(jQuery);
    }
})(function($) {
    "use strict";
    $.ui = $.ui || {};
    return $.ui.version = "1.13.1";
});