define([], function() {
    'use strict';
    return {
        getMpConfig: function(key) {
            if (window.checkout.hasOwnProperty('mpquickcart') && window.checkout.mpquickcart.hasOwnProperty(key)) {
                return window.checkout.mpquickcart[key];
            }
            return null;
        }
    };
});