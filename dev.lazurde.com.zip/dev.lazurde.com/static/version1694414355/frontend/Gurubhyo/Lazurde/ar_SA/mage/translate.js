define(['jquery', 'mage/mage', 'mageTranslationDictionary', 'underscore'], function($, mage, dictionary, _) {
    'use strict';
    $.extend(true, $, {
        mage: {
            translate: (function() {
                var _data = dictionary;
                return {
                    add: function() {
                        if (arguments.length > 1) {
                            _data[arguments[0]] = arguments[1];
                        } else if (typeof arguments[0] === 'object') {
                            $.extend(_data, arguments[0]);
                        }
                    },
                    translate: function(text) {
                        return typeof _data[text] !== 'undefined' ? _data[text] : text;
                    }
                };
            }())
        }
    });
    $.mage.__ = $.proxy($.mage.translate.translate, $.mage.translate);
    _.extend(_, {
        i18n: function(text) {
            return $.mage.__(text);
        }
    });
    return $.mage.__;
});