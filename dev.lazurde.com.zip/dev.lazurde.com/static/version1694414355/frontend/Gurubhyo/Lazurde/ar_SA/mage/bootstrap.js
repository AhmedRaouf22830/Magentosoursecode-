define(['jquery', 'mage/apply/main', 'Magento_Ui/js/lib/knockout/bootstrap'], function($, mage) {
    'use strict';
    $.ajaxSetup({
        cache: false
    });
    setTimeout(mage.apply);
});