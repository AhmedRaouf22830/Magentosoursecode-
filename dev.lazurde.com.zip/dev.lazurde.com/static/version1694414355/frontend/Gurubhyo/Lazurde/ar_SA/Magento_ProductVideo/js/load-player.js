define(['jquery', 'jquery-ui-modules/widget', 'vimeoWrapper'], function($) {
    'use strict';
    var videoRegister = {
        _register: {},
        isRegistered: function(api) {
            return this._register[api] !== undefined;
        },
        isLoaded: function(api) {
            return this._register[api] !== undefined && this._register[api] === true;
        },
        register: function(api, loaded) {
            loaded = loaded || false;
            this._register[api] = loaded;
        }
    };
    $.widget('mage.productVideoLoader', {
        _create: function() {
            switch (this.element.data('type')) {
                case 'youtube':
                    this.element.videoYoutube();
                    this._player = this.element.data('mageVideoYoutube');
                    break;
                case 'vimeo':
                    this.element.videoVimeo();
                    this._player = this.element.data('mageVideoVimeo');
                    break;
                default:
                    throw {
                        name: 'Video Error',
                        message: 'Unknown video type',
                        toString: function() {
                            return this.name + ': ' + this.message;
                        }
                    };
            }
        },
        _initialize: function() {
            this._params = this.element.data('params') || {};
            this._code = this.element.data('code');
            this._width = this.element.data('width');
            this._height = this.element.data('height');
            this._autoplay = !!this.element.data('autoplay');
            this._playing = this._autoplay || false;
            this._loop = this.element.data('loop');
            this._rel = this.element.data('related');
            this.useYoutubeNocookie = this.element.data('youtubenocookie') || false;
            this._responsive = this.element.data('responsive') !== false;
            if (this._responsive === true) {
                this.element.addClass('responsive');
            }
            this._calculateRatio();
        },
        play: function() {
            this._player.play();
        },
        pause: function() {
            this._player.pause();
        },
        stop: function() {
            this._player.stop();
        },
        playing: function() {
            return this._player.playing();
        },
        _calculateRatio: function() {
            if (!this._responsive) {
                return;
            }
            this.element.css('paddingBottom', this._height / this._width * 100 + '%');
        }
    });
    $.widget('mage.videoYoutube', $.mage.productVideoLoader, {
        _create: function() {
            var self = this;
            this._initialize();
            this.element.append('<div></div>');
            this._on(window, {
                'youtubeapiready': function() {
                    var host = 'https://www.youtube.com';
                    if (self.useYoutubeNocookie) {
                        host = 'https://www.youtube-nocookie.com';
                    }
                    if (self._player !== undefined) {
                        return;
                    }
                    self._autoplay = true;
                    if (self._autoplay) {
                        self._params.autoplay = 1;
                    }
                    if (!self._rel) {
                        self._params.rel = 0;
                    }
                    self._player = new window.YT.Player(self.element.children(':first')[0], {
                        height: self._height,
                        width: self._width,
                        videoId: self._code,
                        playerVars: self._params,
                        host: host,
                        events: {
                            'onReady': function onPlayerReady() {
                                self._player.getDuration();
                                self.element.closest('.fotorama__stage__frame').addClass('fotorama__product-video--loaded');
                            },
                            onStateChange: function(data) {
                                switch (window.parseInt(data.data, 10)) {
                                    case 1:
                                        self._playing = true;
                                        break;
                                    default:
                                        self._playing = false;
                                        break;
                                }
                                self._trigger('statechange', {}, data);
                                if (data.data === window.YT.PlayerState.ENDED && self._loop) {
                                    self._player.playVideo();
                                }
                            }
                        }
                    });
                }
            });
            this._loadApi();
        },
        _loadApi: function() {
            var element, scriptTag;
            if (videoRegister.isRegistered('youtube')) {
                if (videoRegister.isLoaded('youtube')) {
                    $(window).trigger('youtubeapiready');
                }
                return;
            }
            if (window.YT) {
                videoRegister.register('youtube', true);
                $(window).trigger('youtubeapiready');
                return;
            }
            videoRegister.register('youtube');
            element = document.createElement('script');
            scriptTag = document.getElementsByTagName('script')[0];
            element.async = true;
            element.src = 'https://www.youtube.com/iframe_api';
            scriptTag.parentNode.insertBefore(element, scriptTag);
            window.onYouTubeIframeAPIReady = function() {
                $(window).trigger('youtubeapiready');
                videoRegister.register('youtube', true);
            };
        },
        play: function() {
            this._player.playVideo();
            this._playing = true;
        },
        pause: function() {
            this._player.pauseVideo();
            this._playing = false;
        },
        stop: function() {
            this._player.stopVideo();
            this._playing = false;
        },
        playing: function() {
            return this._playing;
        },
        _destroy: function() {
            this.stop();
        }
    });
    $.widget('mage.videoVimeo', $.mage.productVideoLoader, {
        _create: function() {
            var timestamp, additionalParams = '',
                src, id;
            this._initialize();
            timestamp = new Date().getTime();
            this._autoplay = true;
            if (this._autoplay) {
                additionalParams += '&autoplay=1';
            }
            if (this._loop) {
                additionalParams += '&loop=1';
            }
            src = 'https://player.vimeo.com/video/' +
                this._code + '?api=1&player_id=vimeo' +
                this._code +
                timestamp +
                additionalParams;
            id = 'vimeo' + this._code + timestamp;
            this.element.append($('<iframe></iframe>').attr('frameborder', 0).attr('id', id).attr('width', this._width).attr('height', this._height).attr('src', src).attr('webkitallowfullscreen', '').attr('mozallowfullscreen', '').attr('allowfullscreen', '').attr('referrerPolicy', 'origin').attr('allow', 'autoplay'));
            this._player = new Vimeo.Player(this.element.children(':first')[0]);
            this._player.ready().then(function() {
                $('#' + id).closest('.fotorama__stage__frame').addClass('fotorama__product-video--loaded');
            });
        },
        play: function() {
            this._player.play();
            this._playing = true;
        },
        pause: function() {
            this._player.pause();
            this._playing = false;
        },
        stop: function() {
            this._player.unload();
            this._playing = false;
        },
        playing: function() {
            return this._playing;
        }
    });
});