(function(c) {
    var l = "";

    function h(n, m) {
        if (!!l) {
            if (!(l in window)) {
                window[l] = {}
            }
            window[l][n] = m
        } else {
            window[n] = m
        }
    }

    function b(n) {
        var m = null;
        if (!!l) {
            m = (window[l] && window[l][n]) ? window[l][n] : null
        } else {
            m = window[n]
        }
        return m
    }
    var d = {
        getBaseDomain: function(m) {
            var o = m.split(".");
            var p = o.length;
            if (p <= 2) {
                return m
            }
            if (o[p - 1].length <= 2 && o[p - 2].length <= 3) {
                return o[p - 3] + "." + o[p - 2] + "." + o[p - 1]
            } else {
                return o[p - 2] + "." + o[p - 1]
            }
        },
        setPersistentCookie: function(q, p, o) {
            var m = new Date();
            m.setDate(m.getDate() + 365 * 100);
            var n = q + "=" + escape(p) + "; expires=" + m.toGMTString() + "; path=/";
            if (o) {
                n = n + "; domain=" + o
            }
            document.cookie = n
        },
        getCookie: function(p) {
            var n = document.cookie;
            if (n && (n.length > 0)) {
                var m = n.indexOf(p + "=");
                if (m != -1) {
                    m = m + p.length + 1;
                    var o = n.indexOf(";", m);
                    if (o == -1) {
                        o = n.length
                    }
                    return unescape(n.substring(m, o))
                }
            }
            return ""
        },
        getSiteLevelVars: function(n, o) {
            for (var m = 0; m < n.length; m++) {
                o[n[m].brVar] = this.getExtractedValue(n[m])
            }
            return o
        },
        getDataLayerObject: function(w, s, n) {
            var r = {};
            if (!s) {
                var q = [];
                for (var o in w) {
                    var u = w[o];
                    for (var p = 0; p < u.length; p++) {
                        if (u[p].brVar == "ptype") {
                            q.push(u[p]);
                            u.splice(p, 1)
                        }
                    }
                }
                if (Object.keys(q).length == 0) {
                    return r
                }
                var t = this.getPType(q);
                if (!t) {
                    if (n.ptype) {
                        s = n.ptype
                    } else {
                        s = "other"
                    }
                } else {
                    s = t
                }
            }
            r.ptype = s;
            var m = w[s];
            if (m) {
                for (var p = 0; p < m.length; p++) {
                    var v = this.getExtractedValue(m[p]);
                    if (v) {
                        r[m[p].brVar] = v
                    }
                }
            }
            return r
        },
        getExtractedValue: function(u) {
            if (!u.mappedTo || u.mappedTo == "") {
                return ""
            }
            var x = u.mappedTo.split(".");
            var t = new Object();
            var w = "";
            var v = "";
            var s = true;
            try {
                if (x[0].indexOf("[") != -1) {
                    var o = x[0].split(/\[(\d+)\]/);
                    t = window[o[0]][o[1]]
                } else {
                    t = window[x[0]]
                }
                var q = t;
                try {
                    for (var r = 1; r < x.length; r++) {
                        var n = x[r];
                        if (n.indexOf("[") != -1) {
                            var m = n.split(/\[(\d+)\]/);
                            q = q[m[0]][m[1]]
                        } else {
                            q = q[n]
                        }
                    }
                } catch (p) {
                    s = false;
                    q = ""
                }
                if (!q) {
                    s = false;
                    w = ""
                } else {
                    w = q
                }
            } catch (p) {
                return v
            }
            if (u.exactMatch) {
                v = w;
                return v
            } else {
                if (u.regexStr && u.regexStr != "") {
                    v = this.applyRegex(w, u.regexStr);
                    return v
                } else {
                    if (u.rule && u.rule != "") {
                        v = this.applyExtractionRule(w, u.rule, s);
                        return v
                    } else {
                        v = w;
                        return v
                    }
                }
            }
        },
        getPType: function(m) {
            var p = ["homepage", "category", "search", "product", "thematic", "other", "mlt", "trending", "personalized"];
            var n = "";
            for (var o = 0; o < m.length; o++) {
                if (!m[o].mappedTo || m[o].mappedTo == "") {
                    continue
                }
                n = this.getExtractedValue(m[o]);
                if (p.indexOf(n) > -1) {
                    return n
                }
            }
            return null
        },
        applyRegex: function(m, q) {
            var p = q.lastIndexOf("/");
            var o = [q.substring(1, p), q.substring(p + 1)];
            var n = new RegExp(o[0], o[1]);
            var r = n.exec(m);
            if (r === null) {
                return ""
            }
            if (r.length > 1) {
                r = decodeURI(r[1])
            } else {
                r = decodeURI(r[0])
            }
            r = r.replace(/\+/g, " ");
            return r
        },
        applyExtractionRule: function(u, s, p) {
            var m = s.split("&");
            var n = m[0];
            var r = m[1];
            var t = m[2];
            if (n == "exists") {
                if (p) {
                    return t
                } else {
                    return u
                }
            } else {
                var q = r.split("!");
                for (var o = 0; o < q.length; o++) {
                    r = q[o];
                    if (n == "contains" && r != "") {
                        if (u.indexOf(r) != -1) {
                            return t
                        } else {
                            continue
                        }
                    } else {
                        if (n == "begins with" && r != "") {
                            if (u.indexOf(r) == 0) {
                                return t
                            } else {
                                continue
                            }
                        } else {
                            if (n == "ends with" && r != "") {
                                if (u.lastIndexOf(r) == (u.length - r.length)) {
                                    return t
                                } else {
                                    continue
                                }
                            }
                        }
                    }
                }
                return u
            }
        },
        addEventHandler: function(n, m, o) {
            if (n.addEventListener) {
                n.addEventListener(m, o, true)
            } else {
                if (n.attachEvent) {
                    n.attachEvent("on" + m, o)
                } else {
                    n["on" + m] = o
                }
            }
        },
        addLoadHandler: function(m) {
            if (document.readyState == "interactive" || document.readyState == "complete" || document.readyState == "loaded") {
                m();
                return
            }
            if (document.addEventListener) {
                document.addEventListener("DOMContentLoaded", m, false)
            } else {
                if (document.attachEvent) {
                    document.attachEvent("onreadystatechange", function() {
                        if (document.readyState === "complete") {
                            m()
                        }
                    })
                }
            }
        },
        extend: function(m, o) {
            for (var n in o) {
                if (o.hasOwnProperty(n)) {
                    m[n] = o[n]
                }
            }
            return m
        },
        testLocalStorage: function() {
            localStorage.setItem("_br_test_storage", "1");
            var m = localStorage.getItem("_br_test_storage") == "1";
            localStorage.removeItem("_br_test_storage");
            return m
        },
        parseBRCookie: function(s) {
            var t = {};
            var n = s.split(":");
            var u = ["uid", "_uid", "hc", "ts"];
            for (var p = 0, m = n.length; p < m; p++) {
                for (var o = 0, r = u.length; o < r; o++) {
                    if (n[p].substring(0, u[o].length) == u[o]) {
                        var q = n[p].split("=");
                        if (q[0] && q[1]) {
                            t[q[0]] = q[1]
                        }
                    }
                }
            }
            return t
        }
    };
    var k = {
        jsonParsing: typeof JSON === "object" && !!JSON.parse && !!JSON.stringify,
        querySelector: typeof document.querySelector === "function" && typeof document.querySelectorAll === "function"
    };
    try {
        k.localStorage = typeof localStorage === "object" && !!localStorage.removeItem && d.testLocalStorage()
    } catch (e) {
        k.localStorage = false
    }
    d.support = k;
    var i = {
        init: function() {
            this.browser = this.searchString(this.dataBrowser) || "An unknown browser";
            this.version = this.searchVersion(navigator.userAgent) || this.searchVersion(navigator.appVersion) || "an unknown version";
            this.OS = this.searchString(this.dataOS) || "an unknown OS";
            urlLength = 60000;
            subUrlLength = 30000;
            if (this.browser == "Explorer") {
                if (this.version <= 6) {
                    urlLength = 1900;
                    subUrlLength = 800
                } else {
                    if (this.version <= 8) {
                        urlLength = 4000;
                        subUrlLength = 1800
                    }
                }
            }
            this.urlLength = urlLength;
            this.subUrlLength = subUrlLength
        },
        searchString: function(p) {
            for (var m = 0; m < p.length; m++) {
                var n = p[m].string;
                var o = p[m].prop;
                this.versionSearchString = p[m].versionSearch || p[m].identity;
                if (n) {
                    if (n.indexOf(p[m].subString) != -1) {
                        return p[m].identity
                    }
                } else {
                    if (o) {
                        return p[m].identity
                    }
                }
            }
        },
        searchVersion: function(n) {
            var m = n.indexOf(this.versionSearchString);
            if (m == -1) {
                return
            }
            return parseFloat(n.substring(m + this.versionSearchString.length + 1))
        },
        dataBrowser: [{
            string: navigator.userAgent,
            subString: "Chrome",
            identity: "Chrome"
        }, {
            string: navigator.userAgent,
            subString: "OmniWeb",
            versionSearch: "OmniWeb/",
            identity: "OmniWeb"
        }, {
            string: navigator.vendor,
            subString: "Apple",
            identity: "Safari",
            versionSearch: "Version"
        }, {
            prop: window.opera,
            identity: "Opera",
            versionSearch: "Version"
        }, {
            string: navigator.vendor,
            subString: "iCab",
            identity: "iCab"
        }, {
            string: navigator.vendor,
            subString: "KDE",
            identity: "Konqueror"
        }, {
            string: navigator.userAgent,
            subString: "Firefox",
            identity: "Firefox"
        }, {
            string: navigator.vendor,
            subString: "Camino",
            identity: "Camino"
        }, {
            string: navigator.userAgent,
            subString: "Netscape",
            identity: "Netscape"
        }, {
            string: navigator.userAgent,
            subString: "MSIE",
            identity: "Explorer",
            versionSearch: "MSIE"
        }, {
            string: navigator.userAgent,
            subString: "Gecko",
            identity: "Mozilla",
            versionSearch: "rv"
        }, {
            string: navigator.userAgent,
            subString: "Mozilla",
            identity: "Netscape",
            versionSearch: "Mozilla"
        }],
        dataOS: [{
            string: navigator.platform,
            subString: "Win",
            identity: "Windows"
        }, {
            string: navigator.platform,
            subString: "Mac",
            identity: "Mac"
        }, {
            string: navigator.userAgent,
            subString: "iPhone",
            identity: "iPhone/iPod"
        }, {
            string: navigator.platform,
            subString: "Linux",
            identity: "Linux"
        }]
    };
    i.init();
    d.browserDetect = i;

    function a(ac) {
        var I = d.getDataLayerObject(f.options.pixelTypes, null, ac);
        I = d.getSiteLevelVars(f.options.siteLevelRules, I);
        d.extend(ac, I);
        var D = "http://p-eu.brsrvr.com/pix.gif";
        var M = "https://p-eu.brsrvr.com/pix.gif";
        var J = "_br_uid_2";
        var m;
        var t = false;
        var H;
        var u;
        var n = "";
        if (!!l) {
            n += "-";
            n += l
        }
        var w = "br-trk.deferredPixel" + n,
            F = "br-trk.deferredData" + n;

        function Y(af) {
            var ad = {};
            for (var ae in af) {
                if (af.hasOwnProperty(ae) && (af[ae] !== c) && (typeof af[ae] !== "function")) {
                    ad[ae] = af[ae]
                }
            }
            return ad
        }
        var ac = Y(ac);

        function X() {
            return Y(ac)
        }

        function o(ad) {
            t = false;
            ac = Y(ad);
            ac.ajax = 1
        }

        function U() {
            if (typeof br_related_rid !== "undefined" && br_related_rid) {
                H = br_related_rid
            }
        }

        function V() {
            var an = d.getCookie(J);
            var am = an && an.length > 0;
            var ag;
            var ao = {};
            if (!am) {
                var ah = Math.round(Math.random() * 10000000000000);
                ag = "uid=" + ah
            } else {
                var ad = an.split(":");
                ag = ad[0];
                if (ag.indexOf("uid=") == -1) {
                    var ah = Math.round(Math.random() * 10000000000000);
                    ag = "uid=" + ah
                }
                for (var ae = 1, ai = ad.length; ae < ai; ae++) {
                    if (ad[ae].substring(0, "_uid".length) == "_uid") {} else {
                        var aj = ad[ae].split("=");
                        if (aj[0] && aj[1]) {
                            ao[aj[0]] = aj[1]
                        }
                    }
                }
            }
            ao.v = ao.v || f.scriptVersion;
            ao.ts = ao.ts || (new Date()).getTime();
            ao.hc = Number(ao.hc || 0) + 1;
            var af = [ag];
            for (var al in ao) {
                af.push(al + "=" + ao[al])
            }
            an = af.join(":");
            if (an != m && an.length < 1000) {
                var ak = d.getBaseDomain(document.domain);
                d.setPersistentCookie(J, an, ak);
                m = d.getCookie(J)
            }
        }

        function v() {
            var af = document.getElementsByTagName("link");
            for (var ae = 0, ad = af.length; ae < ad; ae++) {
                if (af[ae].getAttribute("rel") == "canonical") {
                    return af[ae].getAttribute("href")
                }
            }
            return ""
        }

        function T(ae) {
            var ad = d.browserDetect.subUrlLength;
            if (!ae) {
                return ""
            }
            return ae.length > ad ? ae.substring(0, ad) + "~~" : ae
        }

        function L(ad) {
            if (ad && ad !== "") {
                return ad
            }
            return document.referrer || ""
        }

        function G(ad, ae) {
            return ad + "=" + encodeURIComponent(ae)
        }

        function K(af, ad) {
            var ae = "";
            if (af[ad]) {
                ae = af[ad];
                delete af[ad]
            }
            return ae
        }

        function z(ae) {
            var ad = ae;
            var ah = {};
            var ag = {};
            ag.items = [];
            var af = 0;
            ah.basket = ag;
            ah.basket_value = af;
            return ah
        }

        function E(ai, af, ad) {
            var ag = ".";
            var ah = "cat" + ad + "=" + ai;
            if (af != null && af.length > 0) {
                ah = ah + ":";
                for (var ae = 0; ae < af.length; ae++) {
                    if (ae > 0) {
                        ah = ah + ag
                    }
                    ah = ah + "v" + ae + "=" + af[ae]
                }
            }
            return ah
        }

        function Z(ag) {
            var af = "!";
            var ad = "";
            for (var ae = 0; ae < ag.length; ae++) {
                if (ae > 0) {
                    ad = ad + af
                }
                ad = ad + E(ag[ae].name, ag[ae].view_ids, ae)
            }
            return ad
        }

        function A(ae, ai) {
            var ah = "|",
                ag = [],
                ad;
            if (ai) {
                while (ai && (ai !== ae.parentNode)) {
                    var af = ai.tagName;
                    if (ai.id) {
                        af += "#" + ai.id
                    } else {
                        if (ai.className) {
                            af += "." + ai.className
                        }
                    }
                    if (!ad && ai.tagName === "A") {
                        ad = ai.href
                    }
                    ag.splice(0, 0, af);
                    ai = ai.parentNode
                }
            }
            return {
                path: ag.join(ah),
                href: ad || ""
            }
        }

        function r(ai) {
            var aj = "!";
            var ad = "'";
            var ag = {
                prod_id: "i",
                sku: "s",
                name: "n",
                quantity: "q",
                price: "p",
                mod: "m",
                prod_ver: "r"
            };
            var an = [];
            for (var ak = 0; ak < ai.length; ak++) {
                var af = [];
                for (var al in ai[ak]) {
                    if (al in ag) {
                        var ah = ai[ak][al];
                        if (typeof(ah) == "string") {
                            ah = ah.replace("!", "%21");
                            ah = ah.replace("'", "%27")
                        }
                        af.push([ag[al], ah].join(""))
                    }
                }
                var ae = af.join(ad);
                an.push(ae)
            }
            var am = aj + an.join(aj);
            return am
        }

        function y(af) {
            var ad = new Image();
            var ae = ("https:" === document.location.protocol) ? M : D;
            ad.src = ae + "?" + af
        }

        function C(aq) {
            var au = [];
            au.push(G("acct_id", K(aq, "acct_id")));
            au.push(G("cookie2", m));
            au.push(G("sid", H));
            var ae = K(aq, "is_conversion");
            var al = K(aq, "order_id");
            var ad = K(aq, "basket");
            var an = K(aq, "basket_value");
            if (ae && ae != "" && ae == "1") {
                au.push(G("is_conversion", ae));
                var ar = [];
                var ao = "";
                if (ad && ad.items && ad.items.length > 0) {
                    ar = ad.items
                } else {
                    var ap = z(ad);
                    var am = ap.basket;
                    if (am && am.items && am.items.length > 0) {
                        ar = am.items
                    }
                }
                ao = r(ar);
                au.push(G("basket", ao));
                if (al) {
                    au.push(G("order_id", al))
                }
                if (an) {
                    au.push(G("basket_value", an))
                } else {
                    if (ap.basket_value != 0) {
                        au.push(G("basket_value", ap.basket_value))
                    }
                }
            }
            var at = K(aq, "explicit_referrer");
            au.push(G("ref", T(L(at))));
            au.push(G("tzo", new Date().getTimezoneOffset()));
            au.push(G("rand", Math.random()));
            var af = K(aq, "df_e_catalogs");
            if (af && af.length > 0) {
                var aj = Z(af);
                au.push(G("df_e_catalogs", aj))
            }
            var av = K(aq, "e_catalogs");
            if (av && av.length > 0) {
                var aj = Z(av);
                au.push(G("e_catalogs", aj))
            }
            var ag = K(aq, "df_catalogs");
            if (ag && ag.length > 0) {
                var aj = Z(ag);
                au.push(G("df_catalogs", aj))
            }
            var ak = K(aq, "catalogs");
            if (ak && ak.length > 0) {
                var aj = Z(ak);
                au.push(G("catalogs", aj))
            }
            for (var aw in aq) {
                au.push(G(aw, aq[aw]))
            }
            var ai = T(location.href);
            au.push(G("url", ai));
            var ah = T(v());
            if (ah) {
                au.push(G("rc", 1));
                if (ah != ai) {
                    au.push(G("can_url", ah))
                }
            }
            au.push(G("version", f.scriptVersion));
            return au.join("&")
        }

        function O(am, al) {
            try {
                var ak = b("BrTrkConfig");
                if (ak && typeof ak.pixelLogCallback === "function") {
                    ak.pixelLogCallback(d, am)
                }
            } catch (ah) {}
            am.lang = navigator.language || navigator.browserLanguage;
            var ag = f.options.extraCookies || [];
            for (var ai = 0; ai < ag.length; ai++) {
                var af = ag[ai];
                var ae = d.getCookie(af.name);
                if (ae || ae === false || ae === 0) {
                    var aj = "_ec_" + af.name;
                    if (ae.length <= af.maxLength) {
                        am[aj] = ae
                    } else {
                        am[aj] = ae.substring(0, af.maxLength)
                    }
                }
            }
            var ad = C(am);
            if (ad.length > d.browserDetect.urlLength) {
                ad = ad.substr(0, d.browserDetect.urlLength) + "&tr=1"
            }
            if (al) {
                if (k.localStorage) {
                    localStorage[w] = ad
                }
            } else {
                y(ad)
            }
        }

        function q(ae) {
            B();
            var ai = {};
            if (document.title) {
                ai.title = document.title.substr(0, 200)
            }
            var ag = Y(ac);
            for (var ak in ag) {
                ai[ak] = ag[ak]
            }
            ae = ae || "pageview";
            ai.type = ae;
            if (typeof document.br_custom_data !== "undefined") {
                var al = document.br_custom_data;
                for (var ak in al) {
                    for (var ah in al[ak]) {
                        ai[ak + "_" + ah] = al[ak][ah]
                    }
                }
            }
            try {
                if (k.localStorage && k.jsonParsing && localStorage[F]) {
                    var ad = JSON.parse(localStorage[F]);
                    if (ad) {
                        for (var ak in ad) {
                            if (ad.hasOwnProperty(ak)) {
                                var aj = "df_" + ak;
                                if (typeof ai[aj] === "undefined") {
                                    ai[aj] = ad[ak]
                                }
                            }
                        }
                    }
                    localStorage.removeItem(F)
                }
            } catch (af) {}
            O(ai)
        }

        function P(ae, af) {
            var ad = Y(ac);
            ad.type = "linkclick";
            if (ae) {
                ad.link = ae
            }
            if (af) {
                ad.path = af
            }
            ad.time = (new Date()).getTime() - u;
            O(ad)
        }

        function S(aj, ah, ad, ai, al) {
            var ak = Y(ac);
            ak.group = aj;
            ak.type = "event";
            ak.etype = ah;
            var ae = {};
            if (ah == "quickview") {
                ae = d.getDataLayerObject(f.options.pixelTypes, "quickview", ad)
            } else {
                ae = d.getDataLayerObject(f.options.pixelTypes, "event", ad)
            }
            d.extend(ak, ad);
            d.extend(ak, ai);
            d.extend(ak, ae);
            for (var af in ad) {
                ak["e_" + af] = ad[af]
            }
            try {
                if (al && k.localStorage && k.jsonParsing) {
                    localStorage[F] = JSON.stringify(ak)
                }
            } catch (ag) {}
            O(ak, al)
        }

        function B() {
            if (k.localStorage) {
                var ad = localStorage[w];
                if (ad) {
                    localStorage.removeItem(w);
                    y(ad)
                }
            }
        }

        function x(ad) {
            var ah = ad.length;
            while (ah--) {
                var ag = ad[ah];
                if (ag.event == "dynamic-click") {
                    var ae = document.body;
                    var ai = ag;
                    var af = (function(aj, ak) {
                        return function(ao) {
                            var al = ao || window.event;
                            var an = al.target || al.srcElement;
                            if (an && ((an.id == ak.className || an.id == ak.id) || (an.className == ak.className || an.className == ak.id))) {
                                var am = A(aj, an);
                                S(ak.group, ak.action, {
                                    path: am.path
                                }, {}, ak.deferred)
                            } else {
                                return false
                            }
                        }
                    })(ae, ai);
                    d.addEventHandler(ae, "click", af)
                } else {
                    R(ag)
                }
            }
        }

        function R(ag) {
            if (!ag.event || !ag.group || !ag.action) {
                return false
            }
            var ai = [];
            if (ag.id) {
                var af = document.getElementById(ag.id);
                if (af) {
                    ai.push(af)
                }
            } else {
                if (ag.className) {
                    var ah = [];
                    if (typeof document.getElementsByClassName === "function") {
                        ah = document.getElementsByClassName(ag.className)
                    } else {
                        if (k.querySelector) {
                            ah = document.querySelectorAll("." + ag.className)
                        }
                    }
                    if (ah.length) {
                        ai = ah
                    }
                } else {
                    if (ag.selector && k.querySelector) {
                        var ah = document.querySelectorAll(ag.selector);
                        if (ah.length) {
                            ai = ah
                        }
                    }
                }
            }
            if (ai.length) {
                var ae = ai.length;
                while (ae--) {
                    if (ag.event == "enter") {
                        ag.event = "keydown";
                        var ad = (function(aj) {
                            return function(an) {
                                an.which = an.which || an.keyCode;
                                if (an.which != 13) {
                                    return false
                                }
                                var ak = an || window.event;
                                var am = ak.target || ak.srcElement;
                                if (!am) {
                                    return false
                                }
                                var al = A(aj, am);
                                S(ag.group, ag.action, {
                                    path: al.path
                                }, {}, ag.deferred)
                            }
                        })(ai[ae]);
                        d.addEventHandler(ai[ae], ag.event, ad)
                    } else {
                        var ad = (function(aj) {
                            return function(an) {
                                var ak = an || window.event;
                                var am = ak.target || ak.srcElement;
                                if (!am) {
                                    return false
                                }
                                var al = A(aj, am);
                                S(ag.group, ag.action, {
                                    path: al.path
                                }, {}, ag.deferred)
                            }
                        })(ai[ae]);
                        d.addEventHandler(ai[ae], ag.event, ad)
                    }
                }
                return true
            }
        }

        function W() {
            d.addLoadHandler(function() {
                x(f.options.eventTrackingSelectors.trackedElements)
            })
        }

        function p() {
            if (!f.options.timeTracking) {
                return
            }
            var ad = [5000, 25000, 75000, 150000];
            var af = function(ag) {
                var ah = Y(ac);
                ah.type = "sitetime";
                ah.time = ad[ag];
                O(ah)
            };
            var ae;
            for (ae = 0; ae < ad.length; ++ae) {
                (function(ag) {
                    setTimeout(function() {
                        af(ag)
                    }, ad[ag])
                })(ae)
            }
        }

        function s(ae) {
            var ad;
            for (ad = 0; ad < ae.length; ad++) {
                Q(ae[ad])
            }
        }

        function Q(ad, af, ah) {
            var ag = document.getElementById(ad);
            if (!ag) {
                return false
            }
            var ae = function(al) {
                if (typeof ah === "function") {
                    ah(ac)
                }
                var ai = al || window.event;
                var ak = ai.target || ai.srcElement;
                if (!ak) {
                    return false
                }
                var aj = A(ag, ak);
                P(aj.href, aj.path)
            };
            d.addEventHandler(ag, "mousedown", ae);
            return true
        }

        function N() {
            d.addLoadHandler(function() {
                s(f.options.linkTrackingIds)
            })
        }

        function ab() {
            if (t) {
                return
            }
            q();
            W();
            N();
            p();
            t = true
        }

        function aa() {
            u = (new Date()).getTime();
            V();
            U()
        }
        this.logPageView = q;
        this.logLinkClick = P;
        this.logEvent = S;
        this.addClickTracker = Q;
        this.enableEventTracking = W;
        this.enableLinkTracking = N;
        this.enableTracking = ab;
        this.enableTimeTracking = p;
        this.getBrData = X;
        this.updateBrData = o;
        this.getCookie = d.getCookie;
        aa()
    }
    var j;
    var f = {
        scriptVersion: "15.0",
        acctId: 7235,
        options: {
            extraCookies: [],
            linkTrackingIds: [],
            eventTrackingSelectors: {
                trackedElements: []
            },
            timeTracking: false,
            siteLevelRules: [],
            pixelTypes: {
                category: [{
                    brVar: "ptype",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }, {
                    brVar: "cat",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }, {
                    brVar: "cat_id",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }],
                product: [{
                    brVar: "ptype",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }, {
                    brVar: "prod_id",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }, {
                    brVar: "prod_name",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }, {
                    brVar: "sku",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }],
                homepage: [{
                    brVar: "ptype",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }],
                search: [{
                    brVar: "ptype",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }, {
                    brVar: "search_term",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }],
                thematic: [{
                    brVar: "ptype",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }],
                other: [{
                    brVar: "ptype",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }, {
                    brVar: "is_conversion",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }, {
                    brVar: "basket",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }, {
                    brVar: "basket_value",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }, {
                    brVar: "order_id",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }],
                mlt: [{
                    brVar: "ptype",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }],
                trending: [{
                    brVar: "ptype",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }],
                personalized: [{
                    brVar: "ptype",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }],
                siteRules: [{
                    brVar: "domain_key",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }],
                event: [{
                    brVar: "prod_id",
                    mappedTo: "",
                    exactMatch: false,
                    regexStr: "",
                    rule: ""
                }]
            }
        },
        getTracker: function(m, n) {
            if (!j) {
                j = new a(n)
            }
            return j
        },
        BrUtils: d
    };
    var g = function g(q) {
        try {
            var m = "br_data";
            var n = {};
            if (window[m]) {
                n = window[m]
            }
            n.acct_id = f.acctId;
            if ("globalObjectNamespace" in n && !!n.globalObjectNamespace) {
                l = n.globalObjectNamespace
            }
            h("BrTrk", f);
            if (typeof testBrTrk !== "undefined") {
                h("BrUtils", d);
                h("BrTrkClass", a)
            }
            var p = f.getTracker(0, n);
            p.enableTracking()
        } catch (o) {}
    };
    if (document.readyState === "complete" || (document.readyState !== "loading" && !document.documentElement.doScroll)) {
        g()
    } else {
        f.BrUtils.addEventHandler(window, "load", g)
    }
}());