! function() {
    "use strict";
    try {
        window.snaptr.cfg('31cb6a29-f029-4817-b56c-d9c2f19033fc', {
            "asc": [],
            "a": ["PII"],
            "ipg": "20",
            "b": [],
            "t": "",
            "v": "3.4.17-2311092202"
        })
    } catch (e) {}
}();